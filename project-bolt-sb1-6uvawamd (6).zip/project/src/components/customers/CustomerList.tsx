import React from 'react';
import { Customer, CustomerFormData } from '../../types/customer';
import CustomerForm from './CustomerForm';
import { Pencil, Trash2 } from 'lucide-react';

interface CustomerListProps {
  customers: Customer[];
  editingId: string | null;
  onEdit: (id: string) => void;
  onUpdate: (id: string, data: CustomerFormData) => void;
  onDelete: (id: string) => void;
  onEditComplete: () => void;
}

export default function CustomerList({
  customers,
  editingId,
  onEdit,
  onUpdate,
  onDelete,
  onEditComplete
}: CustomerListProps) {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">氏名</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">フリガナ</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">住所</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">電話番号</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">メール</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">操作</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {customers.map((customer) => (
              <tr key={customer.id}>
                {editingId === customer.id ? (
                  <td colSpan={6} className="px-6 py-4">
                    <CustomerForm
                      initialData={customer}
                      onSubmit={(data) => {
                        onUpdate(customer.id, data);
                        onEditComplete();
                      }}
                      isEditing
                    />
                  </td>
                ) : (
                  <>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{customer.name}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{customer.nameKana}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      〒{customer.postalCode}<br />
                      {customer.address}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{customer.phone}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{customer.email}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      <div className="flex space-x-2">
                        <button
                          onClick={() => onEdit(customer.id)}
                          className="text-blue-600 hover:text-blue-900"
                        >
                          <Pencil className="h-5 w-5" />
                        </button>
                        <button
                          onClick={() => onDelete(customer.id)}
                          className="text-red-600 hover:text-red-900"
                        >
                          <Trash2 className="h-5 w-5" />
                        </button>
                      </div>
                    </td>
                  </>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}