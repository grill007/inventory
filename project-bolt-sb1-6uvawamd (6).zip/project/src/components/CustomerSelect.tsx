import React from 'react';
import { Customer } from '../types/customer';

interface CustomerSelectProps {
  customers: Customer[];
  selectedCustomerId?: string;
  onChange: (customerId: string) => void;
}

export default function CustomerSelect({ 
  customers, 
  selectedCustomerId, 
  onChange 
}: CustomerSelectProps) {
  return (
    <div>
      <label className="block text-sm font-medium text-gray-700">顧客</label>
      <select
        value={selectedCustomerId || ''}
        onChange={(e) => onChange(e.target.value)}
        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
      >
        <option value="">顧客を選択</option>
        {customers.map((customer) => (
          <option key={customer.id} value={customer.id}>
            {customer.name} ({customer.nameKana})
          </option>
        ))}
      </select>
    </div>
  );
}