import React, { useState, useEffect } from 'react';
import { Plus } from 'lucide-react';
import { generateProductCode } from '../utils/productCodeGenerator';
import ProductQRCode from './ProductQRCode';
import CustomerSelect from './CustomerSelect';
import ProductImagesUpload from './ProductImagesUpload';
import { useCustomers } from '../hooks/useCustomers';
import type { ProductFormData, ProductImage } from '../types/inventory';

interface ProductFormProps {
  onSubmit: (data: ProductFormData) => void;
  initialData?: ProductFormData;
  isEditing?: boolean;
}

export default function ProductForm({ onSubmit, initialData, isEditing = false }: ProductFormProps) {
  const { customers } = useCustomers();
  const [formData, setFormData] = useState<ProductFormData>({
    inboundDate: '',
    outboundDate: '',
    name: '',
    purchasePrice: 0,
    sellingPrice: 0,
    productCode: '',
    inStock: true,
    customerId: undefined,
    images: [],
    imageFiles: []
  });
  const [showQRCode, setShowQRCode] = useState(false);

  useEffect(() => {
    if (initialData) {
      setFormData(initialData);
    } else {
      setFormData(prev => ({
        ...prev,
        productCode: generateProductCode()
      }));
    }
  }, [initialData]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
    if (!isEditing) {
      setFormData({
        inboundDate: '',
        outboundDate: '',
        name: '',
        purchasePrice: 0,
        sellingPrice: 0,
        productCode: generateProductCode(),
        inStock: true,
        customerId: undefined,
        images: [],
        imageFiles: []
      });
      setShowQRCode(false);
    }
  };

  const handleImagesSelect = (files: File[]) => {
    setFormData(prev => ({
      ...prev,
      imageFiles: [...(prev.imageFiles || []), ...files]
    }));
  };

  const handleImageRemove = (imageId: string) => {
    setFormData(prev => ({
      ...prev,
      images: prev.images?.filter(img => img.id !== imageId) || []
    }));
  };

  const handleMainImageSet = (imageId: string) => {
    setFormData(prev => ({
      ...prev,
      images: prev.images?.map(img => ({
        ...img,
        isMain: img.id === imageId
      })) || []
    }));
  };

  const selectedCustomer = customers.find(c => c.id === formData.customerId);

  return (
    <div className="bg-white p-6 rounded-lg shadow-md mb-6">
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">入荷日</label>
            <input
              type="date"
              value={formData.inboundDate}
              onChange={(e) => setFormData({ ...formData, inboundDate: e.target.value })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">出荷日</label>
            <input
              type="date"
              value={formData.outboundDate}
              onChange={(e) => setFormData({ ...formData, outboundDate: e.target.value })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">商品名</label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">仕入れ価格</label>
            <input
              type="number"
              value={formData.purchasePrice}
              onChange={(e) => setFormData({ ...formData, purchasePrice: Number(e.target.value) })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">販売価格</label>
            <input
              type="number"
              value={formData.sellingPrice}
              onChange={(e) => setFormData({ ...formData, sellingPrice: Number(e.target.value) })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              required
            />
          </div>
          <div>
            <CustomerSelect
              customers={customers}
              selectedCustomerId={formData.customerId}
              onChange={(id) => setFormData({ ...formData, customerId: id })}
            />
          </div>
        </div>

        <ProductImagesUpload
          images={formData.images || []}
          onImagesSelect={handleImagesSelect}
          onImageRemove={handleImageRemove}
          onMainImageSet={handleMainImageSet}
        />

        <div className="flex justify-between items-center">
          <button
            type="submit"
            className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            <Plus className="h-5 w-5 mr-2" />
            {isEditing ? '更新' : '商品を追加'}
          </button>
          
          {!isEditing && formData.productCode && (
            <div className="text-right">
              <button
                type="button"
                onClick={() => setShowQRCode(!showQRCode)}
                className="text-blue-600 hover:text-blue-800"
              >
                {showQRCode ? 'QRコードを隠す' : 'QRコードを表示'}
              </button>
              {showQRCode && (
                <div className="mt-4">
                  <ProductQRCode 
                    productCode={formData.productCode}
                    customer={selectedCustomer}
                  />
                </div>
              )}
            </div>
          )}
        </div>
      </form>
    </div>
  );
}