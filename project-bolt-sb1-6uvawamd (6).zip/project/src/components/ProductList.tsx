import React, { useState } from 'react';
import { QrCode, Printer, Image as ImageIcon } from 'lucide-react';
import { Product } from '../types/inventory';
import ProductQRCode from './ProductQRCode';
import ProductForm from './ProductForm';
import ProductActions from './ProductActions';
import ImagePreviewModal from './ImagePreviewModal';
import { useNavigate } from 'react-router-dom';

interface ProductListProps {
  products: Product[];
  onDelete: (id: string) => void;
  onToggleStock: (id: string) => void;
  onUpdate: (id: string, data: Product) => void;
}

export default function ProductList({ 
  products, 
  onDelete, 
  onToggleStock, 
  onUpdate
}: ProductListProps) {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [showQRCode, setShowQRCode] = useState<string | null>(null);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const navigate = useNavigate();

  const handlePrintQRCodes = () => {
    navigate('/print-qr-codes', { state: { products } });
  };

  const handleToggleStock = (id: string) => {
    const product = products.find(p => p.id === id);
    if (!product) return;

    if (product.inStock) {
      if (confirm('この商品を在庫なしに変更しますか？')) {
        onToggleStock(id);
      }
    } else {
      if (confirm('この商品を在庫ありに戻しますか？')) {
        onToggleStock(id);
      }
    }
  };

  const getMainImage = (product: Product) => {
    return product.images?.find(img => img.isMain)?.url || 
           product.images?.[0]?.url;
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-end">
        <button
          onClick={handlePrintQRCodes}
          className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
        >
          <Printer className="h-5 w-5 mr-2" />
          QRコード一括印刷
        </button>
      </div>

      {showQRCode && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white p-6 rounded-lg">
            <ProductQRCode productCode={showQRCode} />
            <button
              onClick={() => setShowQRCode(null)}
              className="mt-4 w-full px-4 py-2 bg-gray-100 text-gray-700 rounded hover:bg-gray-200"
            >
              閉じる
            </button>
          </div>
        </div>
      )}

      {selectedImage && (
        <ImagePreviewModal
          imageUrl={selectedImage}
          onClose={() => setSelectedImage(null)}
        />
      )}

      <div className="overflow-x-auto">
        <table className="min-w-full bg-white rounded-lg overflow-hidden">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">画像</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">入荷日</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">商品名</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">仕入れ価格</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">販売価格</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">品番</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">在庫</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">操作</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {products.map((product) => (
              <React.Fragment key={product.id}>
                {editingId === product.id ? (
                  <tr>
                    <td colSpan={8} className="px-6 py-4">
                      <ProductForm
                        initialData={product}
                        onSubmit={(data) => {
                          onUpdate(product.id, { ...data, id: product.id });
                          setEditingId(null);
                        }}
                        isEditing
                      />
                    </td>
                  </tr>
                ) : (
                  <tr className={`hover:bg-gray-50 ${!product.inStock ? 'bg-yellow-50' : ''}`}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {getMainImage(product) ? (
                        <button
                          onClick={() => setSelectedImage(getMainImage(product))}
                          className="relative group"
                        >
                          <img
                            src={getMainImage(product)}
                            alt={product.name}
                            className="w-12 h-12 object-cover rounded-lg"
                          />
                          <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 rounded-lg transition-all duration-200 flex items-center justify-center">
                            <ImageIcon className="h-6 w-6 text-white opacity-0 group-hover:opacity-100 transition-opacity duration-200" />
                          </div>
                        </button>
                      ) : (
                        <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center">
                          <ImageIcon className="h-6 w-6 text-gray-400" />
                        </div>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{product.inboundDate}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{product.name}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">¥{product.purchasePrice.toLocaleString()}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">¥{product.sellingPrice.toLocaleString()}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      <button
                        onClick={() => setShowQRCode(product.productCode)}
                        className="inline-flex items-center text-blue-600 hover:text-blue-800"
                      >
                        <QrCode className="h-4 w-4 mr-1" />
                        {product.productCode}
                      </button>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <button
                        onClick={() => handleToggleStock(product.id)}
                        className={`px-4 py-2 rounded-md text-sm font-medium transition-colors duration-200 ${
                          product.inStock 
                            ? 'bg-green-100 text-green-800 hover:bg-green-200' 
                            : 'bg-red-100 text-red-800 hover:bg-red-200'
                        }`}
                      >
                        {product.inStock ? 'あり' : 'なし'}
                      </button>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      <ProductActions
                        product={product}
                        onEdit={() => setEditingId(product.id)}
                        onDelete={() => onDelete(product.id)}
                      />
                    </td>
                  </tr>
                )}
              </React.Fragment>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}