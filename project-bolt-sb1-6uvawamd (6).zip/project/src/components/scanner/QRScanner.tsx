import React, { useCallback } from 'react';
import QrReader from 'react-qr-scanner';

interface QRScannerProps {
  onScan: (data: string | null) => void;
  onError: (error: Error) => void;
}

export default function QRScanner({ onScan, onError }: QRScannerProps) {
  const handleScan = useCallback((data: { text: string } | null) => {
    if (!data?.text) return onScan(null);
    
    try {
      const parsedData = JSON.parse(data.text);
      onScan(parsedData.code);
    } catch (error) {
      onScan(data.text);
    }
  }, [onScan]);

  return (
    <div className="relative aspect-square w-full max-w-md mx-auto">
      <QrReader
        delay={300}
        onError={onError}
        onScan={handleScan}
        constraints={{
          video: {
            facingMode: { exact: 'environment' },
            width: { ideal: 1280 },
            height: { ideal: 720 }
          }
        }}
        className="w-full h-full rounded-lg"
        style={{ transform: 'scaleX(-1)' }}
      />
      <div className="absolute inset-0 border-2 border-blue-500 pointer-events-none rounded-lg">
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-48 h-48 border-2 border-white border-dashed rounded-lg"></div>
        </div>
      </div>
    </div>
  );
}