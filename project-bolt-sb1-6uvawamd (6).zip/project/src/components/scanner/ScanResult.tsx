import React from 'react';
import { CheckCircle2, AlertCircle } from 'lucide-react';

interface ScanResultProps {
  success: boolean;
  message: string;
}

export default function ScanResult({ success, message }: ScanResultProps) {
  return (
    <div className={`p-4 rounded-md ${success ? 'bg-green-50' : 'bg-red-50'}`}>
      <div className="flex items-center space-x-2">
        {success ? (
          <CheckCircle2 className="h-5 w-5 text-green-400" />
        ) : (
          <AlertCircle className="h-5 w-5 text-red-400" />
        )}
        <p className={`text-sm ${success ? 'text-green-700' : 'text-red-700'}`}>
          {message}
        </p>
      </div>
    </div>
  );
}