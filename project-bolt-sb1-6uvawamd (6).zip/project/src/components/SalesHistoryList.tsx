import React, { useState } from 'react';
import { Product } from '../types/inventory';
import { Customer } from '../types/customer';
import { isWithinInterval, parseISO } from 'date-fns';
import { ArrowUpCircle, Pencil, Trash2, User } from 'lucide-react';
import ProductForm from './ProductForm';
import { formatDate } from '../utils/productUtils';

interface SalesHistoryListProps {
  products: Product[];
  customers: Customer[];
  dateRange: { start: string; end: string };
  onUpdate: (id: string, data: Product) => void;
  onDelete: (id: string) => void;
  onRestoreToInventory: (id: string) => void;
}

export default function SalesHistoryList({ 
  products, 
  customers,
  dateRange, 
  onUpdate, 
  onDelete,
  onRestoreToInventory 
}: SalesHistoryListProps) {
  const [editingId, setEditingId] = useState<string | null>(null);

  const filteredProducts = products.filter(product => {
    if (!dateRange.start || !dateRange.end || !product.outboundDate) return true;
    try {
      const outboundDate = parseISO(product.outboundDate);
      return isWithinInterval(outboundDate, {
        start: parseISO(dateRange.start),
        end: parseISO(dateRange.end)
      });
    } catch (error) {
      console.error('Invalid date:', error);
      return false;
    }
  });

  const getCustomerName = (customerId?: string) => {
    if (!customerId) return '-';
    const customer = customers.find(c => c.id === customerId);
    return customer ? customer.name : '-';
  };

  return (
    <div className="bg-white shadow-md rounded-lg overflow-hidden">
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">出荷日</th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">商品名</th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">品番</th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">顧客</th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">仕入価格</th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">販売価格</th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">利益</th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">操作</th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {filteredProducts.map((product) => (
            <React.Fragment key={product.id}>
              {editingId === product.id ? (
                <tr>
                  <td colSpan={8} className="px-6 py-4">
                    <ProductForm
                      initialData={product}
                      onSubmit={(data) => {
                        onUpdate(product.id, { ...data, id: product.id });
                        setEditingId(null);
                      }}
                      isEditing
                    />
                    <div className="mt-4 flex justify-end">
                      <button
                        onClick={() => setEditingId(null)}
                        className="px-4 py-2 text-sm text-gray-600 hover:text-gray-800"
                      >
                        キャンセル
                      </button>
                    </div>
                  </td>
                </tr>
              ) : (
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {formatDate(product.outboundDate)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{product.name}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{product.productCode}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    <div className="flex items-center">
                      <User className="h-4 w-4 text-gray-400 mr-2" />
                      {getCustomerName(product.customerId)}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    ¥{product.purchasePrice.toLocaleString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    ¥{product.sellingPrice.toLocaleString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    ¥{(product.sellingPrice - product.purchasePrice).toLocaleString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm space-x-2">
                    <button
                      onClick={() => setEditingId(product.id)}
                      className="text-blue-600 hover:text-blue-900"
                      title="編集"
                    >
                      <Pencil className="h-5 w-5" />
                    </button>
                    <button
                      onClick={() => onRestoreToInventory(product.id)}
                      className="text-green-600 hover:text-green-900"
                      title="在庫に戻す"
                    >
                      <ArrowUpCircle className="h-5 w-5" />
                    </button>
                    <button
                      onClick={() => {
                        if (confirm('この販売履歴を削除してもよろしいですか？')) {
                          onDelete(product.id);
                        }
                      }}
                      className="text-red-600 hover:text-red-900"
                      title="削除"
                    >
                      <Trash2 className="h-5 w-5" />
                    </button>
                  </td>
                </tr>
              )}
            </React.Fragment>
          ))}
        </tbody>
      </table>
    </div>
  );
}