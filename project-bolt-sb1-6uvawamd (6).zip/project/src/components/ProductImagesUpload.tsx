import React, { useCallback } from 'react';
import { Upload, X, Image as ImageIcon } from 'lucide-react';
import type { ProductImage } from '../types/inventory';

interface ProductImagesUploadProps {
  images: ProductImage[];
  onImagesSelect: (files: File[]) => void;
  onImageRemove: (imageId: string) => void;
  onMainImageSet: (imageId: string) => void;
}

export default function ProductImagesUpload({
  images,
  onImagesSelect,
  onImageRemove,
  onMainImageSet
}: ProductImagesUploadProps) {
  const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    const files = Array.from(e.dataTransfer.files).filter(file => 
      file.type.startsWith('image/') && 
      images.length + files.length <= 5
    );
    if (files.length > 0) {
      onImagesSelect(files);
    }
  }, [images.length, onImagesSelect]);

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files ? Array.from(e.target.files) : [];
    if (files.length > 0 && images.length + files.length <= 5) {
      onImagesSelect(files);
    }
    e.target.value = ''; // Reset input
  }, [images.length, onImagesSelect]);

  return (
    <div className="space-y-4">
      <label className="block text-sm font-medium text-gray-700">
        商品画像（最大5枚）
      </label>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
        {images.map((image) => (
          <div key={image.id} className="relative group">
            <img
              src={image.url}
              alt="商品画像"
              className={`w-full h-32 object-cover rounded-lg ${
                image.isMain ? 'ring-2 ring-blue-500' : ''
              }`}
            />
            <div className="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg flex items-center justify-center space-x-2">
              {!image.isMain && (
                <button
                  onClick={() => onMainImageSet(image.id)}
                  className="p-1 bg-blue-600 text-white rounded-full hover:bg-blue-700"
                  title="メイン画像に設定"
                >
                  <ImageIcon className="h-4 w-4" />
                </button>
              )}
              <button
                onClick={() => onImageRemove(image.id)}
                className="p-1 bg-red-600 text-white rounded-full hover:bg-red-700"
                title="削除"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            {image.isMain && (
              <span className="absolute top-2 left-2 px-2 py-1 bg-blue-600 text-white text-xs rounded">
                メイン
              </span>
            )}
          </div>
        ))}

        {images.length < 5 && (
          <div
            onDrop={handleDrop}
            onDragOver={(e) => e.preventDefault()}
            className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center hover:border-blue-500 transition-colors"
          >
            <input
              type="file"
              accept="image/*"
              onChange={handleFileSelect}
              className="hidden"
              id="product-images"
              multiple
            />
            <label
              htmlFor="product-images"
              className="cursor-pointer flex flex-col items-center h-full justify-center"
            >
              <Upload className="h-6 w-6 text-gray-400" />
              <span className="mt-2 text-xs text-gray-600">
                画像を追加
              </span>
            </label>
          </div>
        )}
      </div>

      <p className="text-sm text-gray-500">
        {images.length}/5 枚の画像が登録されています
      </p>
    </div>
  );
}