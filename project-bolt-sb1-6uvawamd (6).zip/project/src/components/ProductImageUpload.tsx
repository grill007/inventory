import React, { useCallback } from 'react';
import { Upload, X } from 'lucide-react';

interface ProductImageUploadProps {
  imageUrl?: string;
  onImageSelect: (file: File) => void;
  onImageRemove: () => void;
}

export default function ProductImageUpload({ 
  imageUrl, 
  onImageSelect, 
  onImageRemove 
}: ProductImageUploadProps) {
  const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    if (file && file.type.startsWith('image/')) {
      onImageSelect(file);
    }
  }, [onImageSelect]);

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onImageSelect(file);
    }
  }, [onImageSelect]);

  return (
    <div className="space-y-2">
      <label className="block text-sm font-medium text-gray-700">
        商品画像
      </label>
      
      {imageUrl ? (
        <div className="relative">
          <img
            src={imageUrl}
            alt="商品画像"
            className="w-full h-48 object-cover rounded-lg"
          />
          <button
            onClick={onImageRemove}
            className="absolute top-2 right-2 p-1 bg-red-600 text-white rounded-full hover:bg-red-700"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      ) : (
        <div
          onDrop={handleDrop}
          onDragOver={(e) => e.preventDefault()}
          className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-blue-500 transition-colors"
        >
          <input
            type="file"
            accept="image/*"
            onChange={handleFileSelect}
            className="hidden"
            id="product-image"
          />
          <label
            htmlFor="product-image"
            className="cursor-pointer flex flex-col items-center"
          >
            <Upload className="h-8 w-8 text-gray-400" />
            <span className="mt-2 text-sm text-gray-600">
              クリックまたはドラッグ＆ドロップで画像をアップロード
            </span>
          </label>
        </div>
      )}
    </div>
  );
}