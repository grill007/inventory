import React from 'react';
import { User, UserCheck, UserX } from 'lucide-react';

interface UserListProps {
  users: Array<{
    id: string;
    userId: string;
    displayName: string;
    department?: string;
    isActive: boolean;
    lastLoginAt?: string;
  }>;
  onToggleActive: (userId: string, isActive: boolean) => void;
}

export default function UserList({ users, onToggleActive }: UserListProps) {
  return (
    <div className="bg-white shadow-md rounded-lg overflow-hidden">
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">ユーザー名</th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">部署</th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">最終ログイン</th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">ステータス</th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">操作</th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {users.map((user) => (
            <tr key={user.id}>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="flex items-center">
                  <User className="h-5 w-5 text-gray-400 mr-3" />
                  <div className="text-sm font-medium text-gray-900">
                    {user.displayName}
                  </div>
                </div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                {user.department || '-'}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                {user.lastLoginAt 
                  ? new Date(user.lastLoginAt).toLocaleString()
                  : '未ログイン'}
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                  user.isActive
                    ? 'bg-green-100 text-green-800'
                    : 'bg-red-100 text-red-800'
                }`}>
                  {user.isActive ? '有効' : '無効'}
                </span>
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                <button
                  onClick={() => onToggleActive(user.userId, user.isActive)}
                  className={`inline-flex items-center px-3 py-1 rounded-md text-sm font-medium ${
                    user.isActive
                      ? 'text-red-700 hover:text-red-900'
                      : 'text-green-700 hover:text-green-900'
                  }`}
                >
                  {user.isActive ? (
                    <UserX className="h-4 w-4 mr-1" />
                  ) : (
                    <UserCheck className="h-4 w-4 mr-1" />
                  )}
                  {user.isActive ? '無効化' : '有効化'}
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}