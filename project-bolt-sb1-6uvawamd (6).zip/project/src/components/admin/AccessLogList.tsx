import React from 'react';
import { format } from 'date-fns';

interface AccessLog {
  id: string;
  userId: string;
  action: string;
  resource: string;
  ipAddress?: string;
  userAgent?: string;
  createdAt: string;
}

interface AccessLogListProps {
  logs: AccessLog[];
}

export default function AccessLogList({ logs }: AccessLogListProps) {
  return (
    <div className="bg-white shadow-md rounded-lg overflow-hidden">
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
              日時
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
              アクション
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
              リソース
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
              IPアドレス
            </th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {logs.map((log) => (
            <tr key={log.id}>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                {format(new Date(log.createdAt), 'yyyy/MM/dd HH:mm:ss')}
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                  {log.action}
                </span>
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                {log.resource}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                {log.ipAddress || '-'}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}