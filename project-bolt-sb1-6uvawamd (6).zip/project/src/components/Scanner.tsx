import React from 'react';
import QrReader from 'react-qr-scanner';

interface ScannerProps {
  onScan: (data: string | null) => void;
  onError: (error: any) => void;
}

const Scanner: React.FC<ScannerProps> = ({ onScan, onError }) => {
  const handleScan = (data: any) => {
    if (data?.text) {
      onScan(data.text);
    }
  };

  return (
    <div className="w-full max-w-md mx-auto">
      <QrReader
        delay={300}
        onError={onError}
        onScan={handleScan}
        constraints={{
          video: { facingMode: 'environment' }
        }}
        className="w-full"
      />
    </div>
  );
};

export default Scanner;