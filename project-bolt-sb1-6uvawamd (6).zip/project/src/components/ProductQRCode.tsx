import React from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { Customer } from '../types/customer';

interface ProductQRCodeProps {
  productCode: string;
  productName?: string;
  customer?: Customer;
}

export default function ProductQRCode({ productCode, productName, customer }: ProductQRCodeProps) {
  const qrData = JSON.stringify({
    code: productCode,
    name: productName,
    shipping: customer ? {
      name: customer.name,
      postalCode: customer.postalCode,
      address: customer.address,
      phone: customer.phone
    } : undefined
  });

  return (
    <div className="inline-block p-4 bg-white rounded-lg shadow-sm">
      <QRCodeSVG
        value={qrData}
        size={128}
        level="H"
        includeMargin={true}
      />
      <div className="mt-2 text-center">
        <p className="text-sm font-medium text-gray-900">{productCode}</p>
        {productName && (
          <p className="text-xs text-gray-600">{productName}</p>
        )}
        {customer && (
          <div className="mt-2 text-xs text-gray-600 text-left">
            <p className="font-medium">配送先:</p>
            <p>{customer.name}</p>
            <p>〒{customer.postalCode}</p>
            <p>{customer.address}</p>
            <p>{customer.phone}</p>
          </div>
        )}
      </div>
    </div>
  );
}