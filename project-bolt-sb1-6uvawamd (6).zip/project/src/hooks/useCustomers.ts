import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Customer, CustomerFormData } from '../types/customer';
import { useAuth } from '../contexts/AuthContext';

export function useCustomers() {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuth();

  useEffect(() => {
    if (user) {
      fetchCustomers();
    }
  }, [user]);

  async function fetchCustomers() {
    try {
      const { data, error } = await supabase
        .from('customers')
        .select('*')
        .order('name_kana');

      if (error) throw error;

      setCustomers(data.map(customer => ({
        id: customer.id,
        name: customer.name,
        nameKana: customer.name_kana,
        postalCode: customer.postal_code,
        address: customer.address,
        phone: customer.phone,
        email: customer.email,
        notes: customer.notes
      })));
    } catch (err) {
      setError(err instanceof Error ? err.message : '顧客データの取得に失敗しました');
    } finally {
      setLoading(false);
    }
  }

  async function addCustomer(formData: CustomerFormData) {
    if (!user) return;
    
    try {
      const { error } = await supabase
        .from('customers')
        .insert([{
          name: formData.name,
          name_kana: formData.nameKana,
          postal_code: formData.postalCode,
          address: formData.address,
          phone: formData.phone,
          email: formData.email,
          notes: formData.notes,
          user_id: user.id
        }]);

      if (error) throw error;
      await fetchCustomers();
    } catch (err) {
      setError(err instanceof Error ? err.message : '顧客の追加に失敗しました');
      throw err;
    }
  }

  async function updateCustomer(id: string, formData: CustomerFormData) {
    if (!user) return;

    try {
      const { error } = await supabase
        .from('customers')
        .update({
          name: formData.name,
          name_kana: formData.nameKana,
          postal_code: formData.postalCode,
          address: formData.address,
          phone: formData.phone,
          email: formData.email,
          notes: formData.notes
        })
        .eq('id', id)
        .eq('user_id', user.id);

      if (error) throw error;
      await fetchCustomers();
    } catch (err) {
      setError(err instanceof Error ? err.message : '顧客情報の更新に失敗しました');
      throw err;
    }
  }

  async function deleteCustomer(id: string) {
    if (!user) return;

    try {
      const { error } = await supabase
        .from('customers')
        .delete()
        .eq('id', id)
        .eq('user_id', user.id);

      if (error) throw error;
      await fetchCustomers();
    } catch (err) {
      setError(err instanceof Error ? err.message : '顧客の削除に失敗しました');
      throw err;
    }
  }

  return {
    customers,
    loading,
    error,
    addCustomer,
    updateCustomer,
    deleteCustomer
  };
}