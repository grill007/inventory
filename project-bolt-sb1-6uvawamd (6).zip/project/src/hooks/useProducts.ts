import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Product, ProductFormData, ProductImage } from '../types/inventory';
import { useAuth } from '../contexts/AuthContext';

export function useProducts() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuth();

  useEffect(() => {
    if (user) {
      fetchProducts();
    }
  }, [user]);

  async function fetchProducts() {
    try {
      const { data, error } = await supabase
        .from('products')
        .select(`
          *,
          product_images (
            id,
            url,
            is_main,
            updated_at
          )
        `)
        .eq('user_id', user?.id)
        .order('inbound_date', { ascending: false });

      if (error) throw error;

      setProducts(data.map(product => ({
        id: product.id,
        inboundDate: product.inbound_date,
        outboundDate: product.outbound_date,
        name: product.name,
        purchasePrice: product.purchase_price,
        sellingPrice: product.selling_price,
        productCode: product.product_code,
        inStock: product.in_stock,
        customerId: product.customer_id,
        images: product.product_images.map((image: any) => ({
          id: image.id,
          url: image.url,
          updatedAt: image.updated_at,
          isMain: image.is_main
        }))
      })));
    } catch (err) {
      setError(err instanceof Error ? err.message : '商品データの取得に失敗しました');
    } finally {
      setLoading(false);
    }
  }

  async function uploadProductImage(file: File): Promise<string> {
    const fileExt = file.name.split('.').pop();
    const fileName = `${Math.random()}.${fileExt}`;
    const filePath = `products/${fileName}`;

    const { error: uploadError } = await supabase.storage
      .from('product-images')
      .upload(filePath, file);

    if (uploadError) throw uploadError;

    const { data } = supabase.storage
      .from('product-images')
      .getPublicUrl(filePath);

    return data.publicUrl;
  }

  async function addProductImages(productId: string, files: File[]): Promise<void> {
    if (!user) return;

    try {
      const imageUrls = await Promise.all(files.map(uploadProductImage));
      
      const images = imageUrls.map((url, index) => ({
        product_id: productId,
        url,
        is_main: index === 0 && files.length === 1,
        user_id: user.id
      }));

      const { error } = await supabase
        .from('product_images')
        .insert(images);

      if (error) throw error;
    } catch (err) {
      throw new Error('画像のアップロードに失敗しました');
    }
  }

  async function addProduct(formData: ProductFormData) {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('products')
        .insert([{
          inbound_date: formData.inboundDate,
          outbound_date: formData.outboundDate || null,
          name: formData.name,
          purchase_price: formData.purchasePrice,
          selling_price: formData.sellingPrice,
          product_code: formData.productCode,
          in_stock: formData.inStock,
          customer_id: formData.customerId,
          user_id: user.id
        }])
        .select()
        .single();

      if (error) throw error;

      if (formData.imageFiles?.length) {
        await addProductImages(data.id, formData.imageFiles);
      }

      await fetchProducts();
    } catch (err) {
      setError(err instanceof Error ? err.message : '商品の追加に失敗しました');
      throw err;
    }
  }

  async function updateProductImages(productId: string, images: ProductImage[], newFiles?: File[]) {
    if (!user) return;

    try {
      // 既存の画像を更新
      for (const image of images) {
        const { error } = await supabase
          .from('product_images')
          .update({ is_main: image.isMain })
          .eq('id', image.id)
          .eq('user_id', user.id);

        if (error) throw error;
      }

      // 新しい画像を追加
      if (newFiles?.length) {
        await addProductImages(productId, newFiles);
      }
    } catch (err) {
      throw new Error('画像の更新に失敗しました');
    }
  }

  async function deleteProductImage(imageId: string) {
    if (!user) return;

    try {
      const { error } = await supabase
        .from('product_images')
        .delete()
        .eq('id', imageId)
        .eq('user_id', user.id);

      if (error) throw error;
      await fetchProducts();
    } catch (err) {
      throw new Error('画像の削除に失敗しました');
    }
  }

  async function updateProduct(id: string, formData: ProductFormData) {
    if (!user) return;

    try {
      const { error } = await supabase
        .from('products')
        .update({
          inbound_date: formData.inboundDate,
          outbound_date: formData.outboundDate || null,
          name: formData.name,
          purchase_price: formData.purchasePrice,
          selling_price: formData.sellingPrice,
          product_code: formData.productCode,
          in_stock: formData.inStock,
          customer_id: formData.customerId
        })
        .eq('id', id)
        .eq('user_id', user.id);

      if (error) throw error;

      if (formData.images || formData.imageFiles) {
        await updateProductImages(id, formData.images || [], formData.imageFiles);
      }

      await fetchProducts();
    } catch (err) {
      setError(err instanceof Error ? err.message : '商品の更新に失敗しました');
      throw err;
    }
  }

  async function deleteProduct(id: string) {
    if (!user) return;

    try {
      const { error } = await supabase
        .from('products')
        .delete()
        .eq('id', id)
        .eq('user_id', user.id);

      if (error) throw error;
      await fetchProducts();
    } catch (err) {
      setError(err instanceof Error ? err.message : '商品の削除に失敗しました');
      throw err;
    }
  }

  async function toggleStock(id: string) {
    const product = products.find(p => p.id === id);
    if (!product || !user) return;

    try {
      const { error } = await supabase
        .from('products')
        .update({ in_stock: !product.inStock })
        .eq('id', id)
        .eq('user_id', user.id);

      if (error) throw error;
      await fetchProducts();
    } catch (err) {
      setError(err instanceof Error ? err.message : '在庫状態の更新に失敗しました');
      throw err;
    }
  }

  return {
    products,
    loading,
    error,
    addProduct,
    updateProduct,
    deleteProduct,
    toggleStock,
    deleteProductImage
  };
}