import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';

interface UserProfile {
  id: string;
  userId: string;
  roleId: string;
  displayName: string;
  department?: string;
  isActive: boolean;
  lastLoginAt?: string;
}

interface AccessLog {
  id: string;
  userId: string;
  action: string;
  resource: string;
  ipAddress?: string;
  userAgent?: string;
  createdAt: string;
}

export function useAdmin() {
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();

  useEffect(() => {
    async function checkAdminStatus() {
      if (!user) {
        setIsAdmin(false);
        setLoading(false);
        return;
      }

      try {
        const { data, error } = await supabase
          .from('user_profiles')
          .select(`
            role_id,
            user_roles (
              name
            )
          `)
          .eq('user_id', user.id)
          .single();

        if (error) throw error;
        
        setIsAdmin(data?.user_roles?.name === 'admin');
      } catch (error) {
        console.error('Admin status check failed:', error);
        setIsAdmin(false);
      } finally {
        setLoading(false);
      }
    }

    checkAdminStatus();
  }, [user]);

  async function getUserProfiles(): Promise<UserProfile[]> {
    if (!isAdmin) throw new Error('Unauthorized');

    const { data, error } = await supabase
      .from('user_profiles')
      .select(`
        id,
        user_id,
        role_id,
        display_name,
        department,
        is_active,
        last_login_at
      `)
      .order('display_name');

    if (error) throw error;
    return data;
  }

  async function toggleUserActive(userId: string, isActive: boolean): Promise<void> {
    if (!isAdmin) throw new Error('Unauthorized');

    const { error } = await supabase
      .from('user_profiles')
      .update({ is_active: isActive })
      .eq('user_id', userId);

    if (error) throw error;
  }

  return {
    isAdmin,
    loading,
    getUserProfiles,
    toggleUserActive
  };
}