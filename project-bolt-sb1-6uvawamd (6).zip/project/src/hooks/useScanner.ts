import { useState, useCallback } from 'react';
import { Product } from '../types/inventory';

interface ScanResult {
  success: boolean;
  message: string;
}

export function useScanner(products: Product[], onProductScanned: (product: Product) => void) {
  const [permissionDenied, setPermissionDenied] = useState(false);
  const [scanResult, setScanResult] = useState<ScanResult | null>(null);
  const [scanning, setScanning] = useState(true);

  const handleScan = useCallback((data: string | null) => {
    if (!data || !scanning) return;

    const product = products.find(p => p.productCode === data);
    if (product?.inStock) {
      onProductScanned(product);
      setScanResult({
        success: true,
        message: `商品「${product.name}」を出荷処理しました。`
      });
      setScanning(false);
    } else {
      setScanResult({
        success: false,
        message: '有効な商品が見つかりませんでした。'
      });
    }
  }, [products, scanning, onProductScanned]);

  const handleError = useCallback((error: Error) => {
    if (error.name === 'NotAllowedError') {
      setPermissionDenied(true);
    }
    setScanResult({
      success: false,
      message: 'スキャン中にエラーが発生しました。'
    });
  }, []);

  const reset = useCallback(() => {
    setScanResult(null);
    setScanning(true);
    setPermissionDenied(false);
  }, []);

  return {
    permissionDenied,
    scanResult,
    scanning,
    handleScan,
    handleError,
    reset
  };
}