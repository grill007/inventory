import { useState } from 'react';
import { supabase } from '../lib/supabase';

interface UserRole {
  id: string;
  name: string;
  description?: string;
}

interface NewUser {
  email: string;
  displayName: string;
  department?: string;
  roleId: string;
}

export function useUserManagement() {
  const [roles, setRoles] = useState<UserRole[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  async function fetchRoles() {
    try {
      const { data, error } = await supabase
        .from('user_roles')
        .select('*')
        .order('name');

      if (error) throw error;
      setRoles(data);
      setLoading(false);
    } catch (err) {
      setError('ロールの取得に失敗しました');
      setLoading(false);
    }
  }

  async function createUser(userData: NewUser) {
    try {
      // Create user profile
      const { error: profileError } = await supabase
        .from('user_profiles')
        .insert([{
          user_id: userData.email, // メールアドレスを一時的なIDとして使用
          display_name: userData.displayName,
          department: userData.department,
          role_id: userData.roleId,
          is_active: true
        }]);

      if (profileError) throw profileError;

      return true;
    } catch (err) {
      setError('ユーザーの作成に失敗しました');
      throw err;
    }
  }

  return {
    roles,
    loading,
    error,
    fetchRoles,
    createUser
  };
}