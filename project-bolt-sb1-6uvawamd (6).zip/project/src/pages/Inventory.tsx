import React from 'react';
import { History } from 'lucide-react';
import ProductForm from '../components/ProductForm';
import ProductList from '../components/ProductList';
import { useProducts } from '../hooks/useProducts';
import { needsMoveToHistory, markProductAsSold } from '../utils/productUtils';

export default function Inventory() {
  const { products, addProduct, updateProduct, deleteProduct, toggleStock } = useProducts();

  const handleMoveToHistory = () => {
    const productsToMove = products.filter(needsMoveToHistory);
    if (productsToMove.length === 0) {
      alert('移動が必要な商品がありません。');
      return;
    }

    const confirmed = window.confirm(
      `在庫なしとマークされた${productsToMove.length}件の商品を販売履歴に移動します。\n` +
      'この操作は取り消せません。よろしいですか？'
    );
    
    if (!confirmed) return;

    productsToMove.forEach(product => {
      const updatedProduct = markProductAsSold(product);
      updateProduct(product.id, updatedProduct);
    });

    alert(`${productsToMove.length}件の商品を販売履歴に移動しました。`);
  };

  const inStockProducts = products.filter(p => p.inStock || !p.outboundDate);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">在庫管理</h1>
        <button
          onClick={handleMoveToHistory}
          className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700"
        >
          <History className="h-5 w-5 mr-2" />
          在庫整理
        </button>
      </div>
      <ProductForm onSubmit={addProduct} />
      <ProductList 
        products={inStockProducts}
        onUpdate={updateProduct}
        onDelete={deleteProduct}
        onToggleStock={toggleStock}
      />
    </div>
  );
}