import React from 'react';
import { FileText, Users, History } from 'lucide-react';
import { useProducts } from '../hooks/useProducts';
import { useCustomers } from '../hooks/useCustomers';
import ExcelImportExport from '../components/ExcelImportExport';

export default function DataManagement() {
  const { products, addProduct } = useProducts();
  const { customers, addCustomer } = useCustomers();

  const soldProducts = products.filter(p => !p.inStock && p.outboundDate);
  const inStockProducts = products.filter(p => p.inStock);

  return (
    <div className="space-y-8">
      <h1 className="text-2xl font-bold text-gray-900">データ管理</h1>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {/* 在庫商品 */}
        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center space-x-3 mb-4">
            <FileText className="h-6 w-6 text-blue-600" />
            <h2 className="text-lg font-semibold">在庫商品</h2>
          </div>
          <p className="text-sm text-gray-600 mb-4">
            現在の在庫商品数: {inStockProducts.length}件
          </p>
          <ExcelImportExport
            type="products"
            data={inStockProducts}
            onImport={(data) => {
              data.forEach(product => addProduct(product));
            }}
          />
        </div>

        {/* 顧客データ */}
        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center space-x-3 mb-4">
            <Users className="h-6 w-6 text-green-600" />
            <h2 className="text-lg font-semibold">顧客データ</h2>
          </div>
          <p className="text-sm text-gray-600 mb-4">
            登録顧客数: {customers.length}件
          </p>
          <ExcelImportExport
            type="customers"
            data={customers}
            onImport={(data) => {
              data.forEach(customer => addCustomer(customer));
            }}
          />
        </div>

        {/* 販売履歴 */}
        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="flex items-center space-x-3 mb-4">
            <History className="h-6 w-6 text-purple-600" />
            <h2 className="text-lg font-semibold">販売履歴</h2>
          </div>
          <p className="text-sm text-gray-600 mb-4">
            販売済商品数: {soldProducts.length}件
          </p>
          <ExcelImportExport
            type="sales"
            data={soldProducts}
            onImport={() => {}} // 販売履歴はインポート不可
          />
        </div>
      </div>

      <div className="bg-yellow-50 border border-yellow-200 rounded-md p-4">
        <h3 className="text-sm font-medium text-yellow-800 mb-2">注意事項</h3>
        <ul className="list-disc list-inside text-sm text-yellow-700 space-y-1">
          <li>インポートするExcelファイルは、エクスポートしたファイルと同じ形式である必要があります</li>
          <li>販売履歴のインポートはできません（エクスポートのみ可能）</li>
          <li>大量のデータをインポートする場合は、処理に時間がかかる場合があります</li>
        </ul>
      </div>
    </div>
  );
}