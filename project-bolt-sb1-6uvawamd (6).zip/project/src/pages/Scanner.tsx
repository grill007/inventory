import React, { useCallback } from 'react';
import { useProducts } from '../hooks/useProducts';
import { useScanner } from '../hooks/useScanner';
import QRScanner from '../components/scanner/QRScanner';
import ScanResult from '../components/scanner/ScanResult';
import CameraPermission from '../components/scanner/CameraPermission';
import { markProductAsSold } from '../utils/productUtils';
import type { Product } from '../types/inventory';

export default function ScannerPage() {
  const { products, updateProduct } = useProducts();

  const handleProductScanned = useCallback((product: Product) => {
    const updatedProduct = markProductAsSold(product);
    updateProduct(product.id, updatedProduct);
  }, [updateProduct]);

  const {
    permissionDenied,
    scanResult,
    scanning,
    handleScan,
    handleError,
    reset
  } = useScanner(products, handleProductScanned);

  if (permissionDenied) {
    return (
      <div className="max-w-md mx-auto">
        <CameraPermission onRetry={reset} />
      </div>
    );
  }

  return (
    <div className="max-w-md mx-auto space-y-6">
      <div className="bg-white p-6 rounded-lg shadow-md">
        <h2 className="text-lg font-semibold mb-4">QRコードスキャナー</h2>
        {scanning ? (
          <QRScanner onScan={handleScan} onError={handleError} />
        ) : (
          <button
            onClick={reset}
            className="w-full py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            新しいスキャンを開始
          </button>
        )}
      </div>

      {scanResult && (
        <ScanResult success={scanResult.success} message={scanResult.message} />
      )}
    </div>
  );
}