import React, { useState } from 'react';
import { useCustomers } from '../hooks/useCustomers';
import CustomerForm from '../components/customers/CustomerForm';
import CustomerList from '../components/customers/CustomerList';
import ExcelImportExport from '../components/ExcelImportExport';
import { AlertCircle } from 'lucide-react';

export default function Customers() {
  const { customers, loading, error, addCustomer, updateCustomer, deleteCustomer } = useCustomers();
  const [editingId, setEditingId] = useState<string | null>(null);

  if (loading) {
    return <div className="flex justify-center items-center h-64">読み込み中...</div>;
  }

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-md p-4">
        <div className="flex">
          <AlertCircle className="h-5 w-5 text-red-400" />
          <div className="ml-3">
            <h3 className="text-sm font-medium text-red-800">エラーが発生しました</h3>
            <p className="text-sm text-red-700 mt-2">{error}</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-lg shadow-md">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-semibold">顧客管理</h2>
          <ExcelImportExport
            type="customers"
            data={customers}
            onImport={(data) => {
              data.forEach(customer => addCustomer(customer));
            }}
          />
        </div>
        <CustomerForm onSubmit={addCustomer} />
      </div>

      <CustomerList
        customers={customers}
        onEdit={(id) => setEditingId(id)}
        onUpdate={updateCustomer}
        onDelete={deleteCustomer}
        editingId={editingId}
        onEditComplete={() => setEditingId(null)}
      />
    </div>
  );
}