import React, { useState, useEffect } from 'react';
import { useAdmin } from '../../hooks/useAdmin';
import { useUserManagement } from '../../hooks/useUserManagement';
import UserList from '../../components/admin/UserList';
import UserForm from '../../components/admin/UserForm';
import { AlertCircle } from 'lucide-react';

export default function Users() {
  const { getUserProfiles, toggleUserActive } = useAdmin();
  const { roles, loading: rolesLoading, error: rolesError, fetchRoles, createUser } = useUserManagement();
  const [users, setUsers] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    loadUsers();
    fetchRoles();
  }, []);

  async function loadUsers() {
    try {
      const profiles = await getUserProfiles();
      setUsers(profiles);
    } catch (err) {
      setError('ユーザー情報の取得に失敗しました');
    }
  }

  const handleCreateUser = async (userData) => {
    try {
      await createUser(userData);
      await loadUsers();
    } catch (err) {
      setError('ユーザーの作成に失敗しました');
    }
  };

  const handleToggleActive = async (userId: string, isActive: boolean) => {
    try {
      await toggleUserActive(userId, !isActive);
      await loadUsers();
    } catch (err) {
      setError('ユーザーの状態更新に失敗しました');
    }
  };

  if (rolesLoading) {
    return <div>Loading...</div>;
  }

  if (error || rolesError) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-md p-4">
        <div className="flex">
          <AlertCircle className="h-5 w-5 text-red-400" />
          <div className="ml-3">
            <h3 className="text-sm font-medium text-red-800">エラーが発生しました</h3>
            <p className="text-sm text-red-700 mt-2">{error || rolesError}</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">ユーザー管理</h1>
      </div>

      <UserForm 
        onSubmit={handleCreateUser}
        roles={roles}
      />

      <UserList 
        users={users}
        onToggleActive={handleToggleActive}
      />
    </div>
  );
}