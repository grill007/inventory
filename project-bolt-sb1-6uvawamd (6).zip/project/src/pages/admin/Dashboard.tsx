import React from 'react';
import { Users, Settings, Clock } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { Link } from 'react-router-dom';

export default function AdminDashboard() {
  const { user } = useAuth();

  const menuItems = [
    {
      title: 'ユーザー管理',
      description: 'ユーザーの追加、編集、削除',
      icon: Users,
      path: '/admin/users'
    },
    {
      title: 'システム設定',
      description: 'システム全体の設定管理',
      icon: Settings,
      path: '/admin/settings'
    },
    {
      title: 'アクセスログ',
      description: 'システムの利用履歴',
      icon: Clock,
      path: '/admin/logs'
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">管理者ダッシュボード</h1>
        <p className="mt-2 text-sm text-gray-600">
          ログイン: {user?.email}
        </p>
      </div>

      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {menuItems.map((item) => {
          const Icon = item.icon;
          return (
            <Link
              key={item.path}
              to={item.path}
              className="block p-6 bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow"
            >
              <div className="flex items-center space-x-3">
                <Icon className="h-6 w-6 text-blue-600" />
                <h2 className="text-lg font-semibold text-gray-900">{item.title}</h2>
              </div>
              <p className="mt-2 text-sm text-gray-600">{item.description}</p>
            </Link>
          );
        })}
      </div>
    </div>
  );
}