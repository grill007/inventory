import React, { useState } from 'react';
import { useProducts } from '../hooks/useProducts';
import { useCustomers } from '../hooks/useCustomers';
import { calculateSales } from '../utils/salesCalculator';
import { restoreToInventory } from '../utils/productUtils';
import SalesHistoryList from '../components/SalesHistoryList';
import DateRangePicker from '../components/DateRangePicker';

export default function SalesHistory() {
  const { products, updateProduct, deleteProduct } = useProducts();
  const { customers } = useCustomers();
  const [dateRange, setDateRange] = useState({ start: '', end: '' });
  const soldProducts = products.filter(product => !product.inStock && product.outboundDate);
  
  const salesData = calculateSales(soldProducts, dateRange);

  const handleRestoreToInventory = (id: string) => {
    const product = products.find(p => p.id === id);
    if (!product) return;

    if (confirm('この商品を在庫に戻しますか？')) {
      const restoredProduct = restoreToInventory(product);
      updateProduct(product.id, restoredProduct);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-lg shadow-md">
        <h2 className="text-lg font-semibold mb-4">売上集計</h2>
        <DateRangePicker
          startDate={dateRange.start}
          endDate={dateRange.end}
          onChange={setDateRange}
        />
        <div className="mt-4 p-4 bg-blue-50 rounded-md">
          <p className="text-lg font-medium">
            期間内売上: ¥{salesData.totalSales.toLocaleString()}
          </p>
          <p className="text-sm text-gray-600">
            売上総利益: ¥{salesData.totalProfit.toLocaleString()}
          </p>
        </div>
      </div>
      <SalesHistoryList 
        products={soldProducts}
        customers={customers}
        dateRange={dateRange}
        onUpdate={updateProduct}
        onDelete={deleteProduct}
        onRestoreToInventory={handleRestoreToInventory}
      />
    </div>
  );
}