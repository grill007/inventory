import React, { useRef } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Printer, ArrowLeft } from 'lucide-react';
import ProductQRCode from '../components/ProductQRCode';
import type { Product } from '../types/inventory';

export default function PrintQRCodes() {
  const location = useLocation();
  const navigate = useNavigate();
  const printRef = useRef<HTMLDivElement>(null);
  const allProducts = (location.state?.products || []) as Product[];
  
  // フィルターして在庫ありの商品のみを表示
  const products = allProducts.filter(product => product.inStock);

  const handlePrint = () => {
    if (!printRef.current) return;
    window.print();
  };

  if (products.length === 0) {
    return (
      <div className="container mx-auto p-6">
        <div className="flex justify-between items-center mb-6">
          <button
            onClick={() => navigate(-1)}
            className="inline-flex items-center px-4 py-2 text-sm text-gray-700 hover:text-gray-900"
          >
            <ArrowLeft className="h-5 w-5 mr-2" />
            戻る
          </button>
        </div>
        <div className="bg-yellow-50 border border-yellow-200 rounded-md p-4">
          <p className="text-yellow-700">印刷可能な在庫商品がありません。</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6">
      <div className="flex justify-between items-center mb-6">
        <button
          onClick={() => navigate(-1)}
          className="inline-flex items-center px-4 py-2 text-sm text-gray-700 hover:text-gray-900"
        >
          <ArrowLeft className="h-5 w-5 mr-2" />
          戻る
        </button>
        <button
          onClick={handlePrint}
          className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
        >
          <Printer className="h-5 w-5 mr-2" />
          印刷
        </button>
      </div>

      <div ref={printRef} className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {products.map((product) => (
          <div key={product.id} className="p-4 border rounded-lg">
            <ProductQRCode 
              productCode={product.productCode}
              productName={product.name}
            />
          </div>
        ))}
      </div>
    </div>
  );
}