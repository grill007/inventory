import * as XLSX from 'xlsx';
import { Customer } from '../types/customer';
import { Product } from '../types/inventory';

type ExcelDataType = 'customers' | 'products' | 'sales';

// エクスポート関数
export function exportToExcel(type: ExcelDataType, data: any[]): void {
  let worksheetData: any[];
  let filename: string;

  switch (type) {
    case 'customers':
      worksheetData = data.map(customer => ({
        '氏名': customer.name,
        'フリガナ': customer.nameKana,
        '郵便番号': customer.postalCode,
        '住所': customer.address,
        '電話番号': customer.phone,
        'メールアドレス': customer.email,
        '備考': customer.notes || ''
      }));
      filename = '顧客一覧.xlsx';
      break;

    case 'products':
      worksheetData = data.map(product => ({
        '入荷日': product.inboundDate,
        '商品名': product.name,
        '仕入れ価格': product.purchasePrice,
        '販売価格': product.sellingPrice,
        '品番': product.productCode,
        '在庫状況': product.inStock ? 'あり' : 'なし'
      }));
      filename = '商品一覧.xlsx';
      break;

    case 'sales':
      worksheetData = data.map(product => ({
        '出荷日': product.outboundDate,
        '商品名': product.name,
        '品番': product.productCode,
        '仕入れ価格': product.purchasePrice,
        '販売価格': product.sellingPrice,
        '利益': product.sellingPrice - product.purchasePrice
      }));
      filename = '販売履歴.xlsx';
      break;

    default:
      throw new Error('不正なデータ型です');
  }

  const worksheet = XLSX.utils.json_to_sheet(worksheetData);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Sheet1');
  XLSX.writeFile(workbook, filename);
}

// インポート関数
export async function importFromExcel(type: ExcelDataType, file: File): Promise<any[]> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        const worksheet = workbook.Sheets[workbook.SheetNames[0]];
        const jsonData = XLSX.utils.sheet_to_json(worksheet);

        switch (type) {
          case 'customers':
            resolve(jsonData.map(row => ({
              name: row['氏名'],
              nameKana: row['フリガナ'],
              postalCode: row['郵便番号'],
              address: row['住所'],
              phone: row['電話番号'],
              email: row['メールアドレス'],
              notes: row['備考']
            })));
            break;

          case 'products':
            resolve(jsonData.map(row => ({
              inboundDate: row['入荷日'],
              name: row['商品名'],
              purchasePrice: Number(row['仕入れ価格']),
              sellingPrice: Number(row['販売価格']),
              productCode: row['品番'],
              inStock: row['在庫状況'] === 'あり'
            })));
            break;

          default:
            reject(new Error('不正なデータ型です'));
        }
      } catch (error) {
        reject(error);
      }
    };
    reader.readAsArrayBuffer(file);
  });
}