export function generateProductCode(): string {
  const charset = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  const codeLength = 8;
  let code = '';
  
  // 現在のタイムスタンプを16進数で追加（一意性を高めるため）
  const timestamp = Date.now().toString(16).slice(-6).toUpperCase();
  code += timestamp;
  
  // 残りの文字をランダムに生成
  const remainingLength = codeLength - timestamp.length;
  for (let i = 0; i < remainingLength; i++) {
    const randomIndex = Math.floor(Math.random() * charset.length);
    code += charset[randomIndex];
  }
  
  return code;
}