import { Product } from '../types/inventory';

export function markProductAsSold(product: Product): Product {
  const now = new Date().toISOString().split('T')[0];
  return {
    ...product,
    outboundDate: now,
    inStock: false
  };
}

export function restoreToInventory(product: Product): Product {
  return {
    ...product,
    outboundDate: null,
    inStock: true
  };
}

export function isProductInStock(product: Product): boolean {
  return product.inStock;
}

export function isProductSold(product: Product): boolean {
  return !product.inStock && Boolean(product.outboundDate);
}

// 在庫整理が必要な商品かどうかを判定
export function needsMoveToHistory(product: Product): boolean {
  // 在庫なしかつ出荷日が設定されていない商品のみを対象とする
  return !product.inStock && !product.outboundDate;
}

// 在庫整理対象の商品数を取得
export function getProductsToMoveCount(products: Product[]): number {
  return products.filter(needsMoveToHistory).length;
}

export function formatDate(date: string | null): string {
  return date || '';
}