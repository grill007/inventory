import { isWithinInterval, parseISO } from 'date-fns';
import { Product } from '../types/inventory';

interface DateRange {
  start: string;
  end: string;
}

interface SalesData {
  totalSales: number;
  totalProfit: number;
}

export function calculateSales(products: Product[], dateRange: DateRange): SalesData {
  if (!dateRange.start || !dateRange.end) {
    return {
      totalSales: 0,
      totalProfit: 0
    };
  }

  const start = parseISO(dateRange.start);
  const end = parseISO(dateRange.end);

  const filteredProducts = products.filter(product => {
    if (!product.outboundDate) return false;
    const outboundDate = parseISO(product.outboundDate);
    return isWithinInterval(outboundDate, { start, end });
  });

  return filteredProducts.reduce(
    (acc, product) => ({
      totalSales: acc.totalSales + product.sellingPrice,
      totalProfit: acc.totalProfit + (product.sellingPrice - product.purchasePrice)
    }),
    { totalSales: 0, totalProfit: 0 }
  );
}