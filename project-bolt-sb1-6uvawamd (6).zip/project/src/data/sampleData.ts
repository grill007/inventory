import { Product } from '../types/inventory';

export const sampleData: Product[] = [
  {
    id: '1',
    inboundDate: '2023-12-06',
    outboundDate: '2023-12-10',
    name: 'スマートフォン',
    purchasePrice: 1000,
    sellingPrice: 1500,
    productCode: '12345678',
    inStock: false
  },
  {
    id: '2',
    inboundDate: '2023-12-06',
    outboundDate: '2023-12-11',
    name: 'スマートフォン',
    purchasePrice: 1500,
    sellingPrice: 2000,
    productCode: '54321',
    inStock: true
  }
];