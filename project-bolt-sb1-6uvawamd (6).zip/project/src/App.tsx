import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import PrivateRoute from './components/PrivateRoute';
import Layout from './components/Layout';
import Login from './pages/Login';
import AdminRoutes from './routes/AdminRoutes';
import Inventory from './pages/Inventory';
import Customers from './pages/Customers';
import SalesHistory from './pages/SalesHistory';
import Scanner from './pages/Scanner';
import PrintQRCodes from './pages/PrintQRCodes';
import DataManagement from './pages/DataManagement';

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/admin/*" element={<AdminRoutes />} />
          <Route
            path="/"
            element={
              <PrivateRoute>
                <Layout />
              </PrivateRoute>
            }
          >
            <Route index element={<Inventory />} />
            <Route path="customers" element={<Customers />} />
            <Route path="sales-history" element={<SalesHistory />} />
            <Route path="scanner" element={<Scanner />} />
            <Route path="print-qr-codes" element={<PrintQRCodes />} />
            <Route path="data-management" element={<DataManagement />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}