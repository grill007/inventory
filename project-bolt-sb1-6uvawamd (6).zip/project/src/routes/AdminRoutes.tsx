import React from 'react';
import { Route, Routes, Navigate } from 'react-router-dom';
import AdminDashboard from '../pages/admin/Dashboard';
import Users from '../pages/admin/Users';
import { useAdmin } from '../hooks/useAdmin';

export default function AdminRoutes() {
  const { isAdmin, loading } = useAdmin();

  if (loading) {
    return <div>Loading...</div>;
  }

  if (!isAdmin) {
    return <Navigate to="/" />;
  }

  return (
    <Routes>
      <Route path="/" element={<AdminDashboard />} />
      <Route path="/users" element={<Users />} />
      <Route path="*" element={<Navigate to="/admin" />} />
    </Routes>
  );
}