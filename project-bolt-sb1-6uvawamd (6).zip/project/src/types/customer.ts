export interface Customer {
  id: string;
  name: string;
  nameKana: string;
  postalCode: string;
  address: string;
  phone: string;
  email: string;
  notes?: string;
}

export interface CustomerFormData {
  name: string;
  nameKana: string;
  postalCode: string;
  address: string;
  phone: string;
  email: string;
  notes?: string;
}