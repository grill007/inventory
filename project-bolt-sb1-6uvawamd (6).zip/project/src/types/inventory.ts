export interface ProductImage {
  id: string;
  url: string;
  updatedAt: string;
  isMain: boolean;
}

export interface Product {
  id: string;
  inboundDate: string;
  outboundDate: string;
  name: string;
  purchasePrice: number;
  sellingPrice: number;
  productCode: string;
  inStock: boolean;
  customerId?: string;
  images: ProductImage[];
}

export interface ProductFormData {
  inboundDate: string;
  outboundDate: string;
  name: string;
  purchasePrice: number;
  sellingPrice: number;
  productCode: string;
  inStock: boolean;
  customerId?: string;
  imageFiles?: File[];
  images?: ProductImage[];
}