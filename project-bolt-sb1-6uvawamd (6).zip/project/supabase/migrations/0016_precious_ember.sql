/*
  # Fix RLS policies with simplified approach

  1. Changes
    - Drop existing policies
    - Create direct admin check function
    - Create new policies with unique names
    - Refresh indexes

  2. Security
    - Maintain same security model but with simpler implementation
    - Use direct role check to avoid recursion
*/

-- Drop existing policies
DROP POLICY IF EXISTS "roles_read_policy_v9" ON user_roles;
DROP POLICY IF EXISTS "profiles_read_policy_v9" ON user_profiles;
DROP POLICY IF EXISTS "profiles_insert_policy_v9" ON user_profiles;
DROP POLICY IF EXISTS "profiles_update_policy_v9" ON user_profiles;
DROP POLICY IF EXISTS "profiles_delete_policy_v9" ON user_profiles;

-- Create direct admin check function
CREATE OR REPLACE FUNCTION check_is_admin_v3(user_uid uuid)
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 
    FROM user_roles r
    JOIN user_profiles up ON up.role_id = r.id
    WHERE up.user_id = user_uid
    AND r.name = 'admin'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create new policies with unique names
CREATE POLICY "roles_read_policy_v17"
  ON user_roles
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "profiles_read_policy_v17"
  ON user_profiles
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid() OR check_is_admin_v3(auth.uid()));

CREATE POLICY "profiles_insert_policy_v17"
  ON user_profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (check_is_admin_v3(auth.uid()));

CREATE POLICY "profiles_update_policy_v17"
  ON user_profiles
  FOR UPDATE
  TO authenticated
  USING (check_is_admin_v3(auth.uid()));

CREATE POLICY "profiles_delete_policy_v17"
  ON user_profiles
  FOR DELETE
  TO authenticated
  USING (check_is_admin_v3(auth.uid()));

-- Refresh indexes
DROP INDEX IF EXISTS idx_user_profiles_user_id;
DROP INDEX IF EXISTS idx_user_profiles_role_id;
DROP INDEX IF EXISTS idx_user_roles_name;
DROP INDEX IF EXISTS idx_user_profiles_user_role;

CREATE INDEX idx_user_profiles_user_id ON user_profiles(user_id);
CREATE INDEX idx_user_profiles_role_id ON user_profiles(role_id);
CREATE INDEX idx_user_roles_name ON user_roles(name);
CREATE INDEX idx_user_profiles_user_role ON user_profiles(user_id, role_id);