/*
  # Fix user management policies

  1. Changes
    - Drop existing policies to avoid conflicts
    - Create simplified policies with unique names
    - Add performance indexes
  
  2. Security
    - Enable RLS on all tables
    - Ensure proper access control for admin operations
    - Prevent recursive policy evaluation
*/

-- Drop ALL existing policies
DROP POLICY IF EXISTS "anyone_can_read_roles_new" ON user_roles;
DROP POLICY IF EXISTS "users_can_read_own_profile_new" ON user_profiles;
DROP POLICY IF EXISTS "admins_can_insert_profiles_new" ON user_profiles;
DROP POLICY IF EXISTS "admins_can_update_profiles_new" ON user_profiles;
DROP POLICY IF EXISTS "allow_read_roles" ON user_roles;
DROP POLICY IF EXISTS "allow_read_profiles" ON user_profiles;
DROP POLICY IF EXISTS "allow_insert_profiles" ON user_profiles;
DROP POLICY IF EXISTS "allow_update_profiles" ON user_profiles;
DROP POLICY IF EXISTS "allow_delete_profiles" ON user_profiles;
DROP POLICY IF EXISTS "read_roles" ON user_roles;
DROP POLICY IF EXISTS "read_own_profile" ON user_profiles;
DROP POLICY IF EXISTS "admin_insert_profile" ON user_profiles;
DROP POLICY IF EXISTS "admin_update_profile" ON user_profiles;
DROP POLICY IF EXISTS "admin_delete_profile" ON user_profiles;

-- Create simple read-only policy for user_roles with unique name
CREATE POLICY "read_roles_v2"
  ON user_roles
  FOR SELECT
  TO authenticated
  USING (true);

-- Create non-recursive policies for user_profiles with unique names
CREATE POLICY "read_own_profile_v2"
  ON user_profiles
  FOR SELECT
  TO authenticated
  USING (
    user_id = auth.uid() OR
    role_id IN (
      SELECT id FROM user_roles 
      WHERE name = 'admin'
    )
  );

CREATE POLICY "admin_insert_profile_v2"
  ON user_profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (
    role_id IN (
      SELECT id FROM user_roles 
      WHERE name = 'admin'
    )
  );

CREATE POLICY "admin_update_profile_v2"
  ON user_profiles
  FOR UPDATE
  TO authenticated
  USING (
    role_id IN (
      SELECT id FROM user_roles 
      WHERE name = 'admin'
    )
  );

CREATE POLICY "admin_delete_profile_v2"
  ON user_profiles
  FOR DELETE
  TO authenticated
  USING (
    role_id IN (
      SELECT id FROM user_roles 
      WHERE name = 'admin'
    )
  );

-- Ensure indexes exist for performance
CREATE INDEX IF NOT EXISTS idx_user_profiles_user_id ON user_profiles(user_id);
CREATE INDEX IF NOT EXISTS idx_user_profiles_role_id ON user_profiles(role_id);
CREATE INDEX IF NOT EXISTS idx_user_roles_name ON user_roles(name);
CREATE INDEX IF NOT EXISTS idx_user_profiles_user_role ON user_profiles(user_id, role_id);