/*
  # Add product images support
  
  1. Changes
    - Add image_url column to products table
    - Add image_updated_at column for tracking image updates
    
  2. Notes
    - image_url stores the Supabase Storage public URL
    - Null values are allowed for backwards compatibility
*/

ALTER TABLE products
ADD COLUMN IF NOT EXISTS image_url text,
ADD COLUMN IF NOT EXISTS image_updated_at timestamptz;