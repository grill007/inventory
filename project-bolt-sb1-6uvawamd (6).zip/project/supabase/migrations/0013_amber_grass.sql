/*
  # Fix user policies

  1. Changes
    - Drop existing problematic policies
    - Create simplified non-recursive policies
    - Add performance indexes
    
  2. Security
    - Maintain proper access control
    - Prevent infinite recursion
    - Optimize query performance
*/

-- Drop existing policies
DROP POLICY IF EXISTS "read_roles" ON user_roles;
DROP POLICY IF EXISTS "read_own_profile" ON user_profiles;
DROP POLICY IF EXISTS "admin_insert_profile" ON user_profiles;
DROP POLICY IF EXISTS "admin_update_profile" ON user_profiles;
DROP POLICY IF EXISTS "admin_delete_profile" ON user_profiles;

-- Create simple read-only policy for user_roles
CREATE POLICY "allow_read_roles"
  ON user_roles
  FOR SELECT
  TO authenticated
  USING (true);

-- Create simplified policies for user_profiles
CREATE POLICY "allow_read_profiles"
  ON user_profiles
  FOR SELECT
  TO authenticated
  USING (
    user_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM user_roles r
      JOIN user_profiles p ON p.role_id = r.id
      WHERE p.user_id = auth.uid()
      AND r.name = 'admin'
    )
  );

CREATE POLICY "allow_insert_profiles"
  ON user_profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_roles r
      JOIN user_profiles p ON p.role_id = r.id
      WHERE p.user_id = auth.uid()
      AND r.name = 'admin'
    )
  );

CREATE POLICY "allow_update_profiles"
  ON user_profiles
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles r
      JOIN user_profiles p ON p.role_id = r.id
      WHERE p.user_id = auth.uid()
      AND r.name = 'admin'
    )
  );

CREATE POLICY "allow_delete_profiles"
  ON user_profiles
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles r
      JOIN user_profiles p ON p.role_id = r.id
      WHERE p.user_id = auth.uid()
      AND r.name = 'admin'
    )
  );

-- Ensure indexes exist for performance
CREATE INDEX IF NOT EXISTS idx_user_profiles_user_id ON user_profiles(user_id);
CREATE INDEX IF NOT EXISTS idx_user_profiles_role_id ON user_profiles(role_id);
CREATE INDEX IF NOT EXISTS idx_user_roles_name ON user_roles(name);
CREATE INDEX IF NOT EXISTS idx_user_profiles_user_role ON user_profiles(user_id, role_id);