/*
  # Fix recursive policies

  1. Changes
    - Remove recursive policy checks
    - Simplify admin role verification
    - Add direct role checks
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Allow all operations for admin" ON user_profiles;
DROP POLICY IF EXISTS "Anyone can view roles" ON user_roles;
DROP POLICY IF EXISTS "Admins can insert roles" ON user_roles;
DROP POLICY IF EXISTS "Admins can update roles" ON user_roles;
DROP POLICY IF EXISTS "Admins can delete roles" ON user_roles;

-- Create new non-recursive policies for user_profiles
CREATE POLICY "user_profiles_policy"
  ON user_profiles
  TO authenticated
  USING (
    user_id = auth.uid() OR
    role_id = (SELECT id FROM user_roles WHERE name = 'admin' LIMIT 1)
  )
  WITH CHECK (
    user_id = auth.uid() OR
    role_id = (SELECT id FROM user_roles WHERE name = 'admin' LIMIT 1)
  );

-- Create new non-recursive policies for user_roles
CREATE POLICY "user_roles_policy"
  ON user_roles
  TO authenticated
  USING (true)
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_profiles.user_id = auth.uid()
      AND user_profiles.role_id = (
        SELECT id FROM user_roles WHERE name = 'admin' LIMIT 1
      )
    )
  );

-- Ensure admin user exists and has correct role
DO $$
DECLARE
  admin_role_id uuid;
  admin_user_id uuid;
BEGIN
  -- Get or create admin role
  INSERT INTO user_roles (name, description)
  VALUES ('admin', '管理者')
  ON CONFLICT (name) DO UPDATE SET name = 'admin'
  RETURNING id INTO admin_role_id;

  -- Get or create admin user
  SELECT id INTO admin_user_id
  FROM auth.users
  WHERE email = 'shiraishi@infogrip.net';

  IF admin_user_id IS NULL THEN
    INSERT INTO auth.users (
      email,
      encrypted_password,
      email_confirmed_at,
      raw_app_meta_data,
      raw_user_meta_data
    ) VALUES (
      'shiraishi@infogrip.net',
      crypt('gripgrip2', gen_salt('bf')),
      now(),
      '{"provider": "email", "providers": ["email"]}',
      '{}'
    )
    RETURNING id INTO admin_user_id;
  END IF;

  -- Ensure admin profile exists
  INSERT INTO user_profiles (user_id, role_id, display_name)
  VALUES (admin_user_id, admin_role_id, 'システム管理者')
  ON CONFLICT (user_id) 
  DO UPDATE SET role_id = admin_role_id;
END $$;