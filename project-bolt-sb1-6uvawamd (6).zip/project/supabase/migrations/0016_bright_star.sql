/*
  # Fix policy migration

  1. Changes
    - Drop existing policies with v8 suffix
    - Create new policies with v9 suffix
    - Optimize policy queries with JOINs
    - Add safety checks for indexes
    
  2. Security
    - Maintain RLS policies
    - Fix recursive policy issues
    - Ensure proper access control
*/

-- Drop ALL existing policies
DROP POLICY IF EXISTS "roles_read_policy_v8" ON user_roles;
DROP POLICY IF EXISTS "profiles_read_policy_v8" ON user_profiles;
DROP POLICY IF EXISTS "profiles_insert_policy_v8" ON user_profiles;
DROP POLICY IF EXISTS "profiles_update_policy_v8" ON user_profiles;
DROP POLICY IF EXISTS "profiles_delete_policy_v8" ON user_profiles;

-- Create simple read-only policy for user_roles with unique name
CREATE POLICY "roles_read_policy_v9"
  ON user_roles
  FOR SELECT
  TO authenticated
  USING (true);

-- Create simplified non-recursive policies for user_profiles
CREATE POLICY "profiles_read_policy_v9"
  ON user_profiles
  FOR SELECT
  TO authenticated
  USING (
    user_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM user_roles r
      JOIN user_profiles up ON up.role_id = r.id
      WHERE up.user_id = auth.uid()
      AND r.name = 'admin'
    )
  );

CREATE POLICY "profiles_insert_policy_v9"
  ON user_profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_roles r
      JOIN user_profiles up ON up.role_id = r.id
      WHERE up.user_id = auth.uid()
      AND r.name = 'admin'
    )
  );

CREATE POLICY "profiles_update_policy_v9"
  ON user_profiles
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles r
      JOIN user_profiles up ON up.role_id = r.id
      WHERE up.user_id = auth.uid()
      AND r.name = 'admin'
    )
  );

CREATE POLICY "profiles_delete_policy_v9"
  ON user_profiles
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles r
      JOIN user_profiles up ON up.role_id = r.id
      WHERE up.user_id = auth.uid()
      AND r.name = 'admin'
    )
  );

-- Ensure indexes exist for performance
DO $$ 
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_user_profiles_user_id') THEN
    CREATE INDEX idx_user_profiles_user_id ON user_profiles(user_id);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_user_profiles_role_id') THEN
    CREATE INDEX idx_user_profiles_role_id ON user_profiles(role_id);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_user_roles_name') THEN
    CREATE INDEX idx_user_roles_name ON user_roles(name);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_user_profiles_user_role') THEN
    CREATE INDEX idx_user_profiles_user_role ON user_profiles(user_id, role_id);
  END IF;
END $$;