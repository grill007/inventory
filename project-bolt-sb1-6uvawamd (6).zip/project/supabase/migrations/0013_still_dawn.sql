/*
  # Fix user policies v4

  1. Changes
    - Drop all existing policies
    - Create simplified non-recursive policies
    - Add performance indexes
    
  2. Security
    - Maintain proper access control
    - Prevent infinite recursion
    - Optimize query performance
*/

-- Drop ALL existing policies
DROP POLICY IF EXISTS "read_roles" ON user_roles;
DROP POLICY IF EXISTS "read_own_profile" ON user_profiles;
DROP POLICY IF EXISTS "admin_insert_profile" ON user_profiles;
DROP POLICY IF EXISTS "admin_update_profile" ON user_profiles;
DROP POLICY IF EXISTS "admin_delete_profile" ON user_profiles;
DROP POLICY IF EXISTS "read_roles_v2" ON user_roles;
DROP POLICY IF EXISTS "read_own_profile_v2" ON user_profiles;
DROP POLICY IF EXISTS "admin_insert_profile_v2" ON user_profiles;
DROP POLICY IF EXISTS "admin_update_profile_v2" ON user_profiles;
DROP POLICY IF EXISTS "admin_delete_profile_v2" ON user_profiles;
DROP POLICY IF EXISTS "read_roles_v3" ON user_roles;
DROP POLICY IF EXISTS "read_own_profile_v3" ON user_profiles;
DROP POLICY IF EXISTS "admin_insert_profile_v3" ON user_profiles;
DROP POLICY IF EXISTS "admin_update_profile_v3" ON user_profiles;
DROP POLICY IF EXISTS "admin_delete_profile_v3" ON user_profiles;

-- Create simple read-only policy for user_roles with unique name
CREATE POLICY "read_roles_v4"
  ON user_roles
  FOR SELECT
  TO authenticated
  USING (true);

-- Create simplified non-recursive policies for user_profiles
CREATE POLICY "read_own_profile_v4"
  ON user_profiles
  FOR SELECT
  TO authenticated
  USING (
    user_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM user_roles r
      WHERE r.id IN (
        SELECT role_id FROM user_profiles
        WHERE user_id = auth.uid()
      )
      AND r.name = 'admin'
    )
  );

CREATE POLICY "admin_insert_profile_v4"
  ON user_profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_roles r
      WHERE r.id IN (
        SELECT role_id FROM user_profiles
        WHERE user_id = auth.uid()
      )
      AND r.name = 'admin'
    )
  );

CREATE POLICY "admin_update_profile_v4"
  ON user_profiles
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles r
      WHERE r.id IN (
        SELECT role_id FROM user_profiles
        WHERE user_id = auth.uid()
      )
      AND r.name = 'admin'
    )
  );

CREATE POLICY "admin_delete_profile_v4"
  ON user_profiles
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles r
      WHERE r.id IN (
        SELECT role_id FROM user_profiles
        WHERE user_id = auth.uid()
      )
      AND r.name = 'admin'
    )
  );

-- Ensure indexes exist for performance
CREATE INDEX IF NOT EXISTS idx_user_profiles_user_id ON user_profiles(user_id);
CREATE INDEX IF NOT EXISTS idx_user_profiles_role_id ON user_profiles(role_id);
CREATE INDEX IF NOT EXISTS idx_user_roles_name ON user_roles(name);
CREATE INDEX IF NOT EXISTS idx_user_profiles_user_role ON user_profiles(user_id, role_id);