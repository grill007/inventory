/*
  # Fix RLS policies and indexes

  1. Changes
    - Drop ALL existing policies
    - Create new simplified policies
    - Add performance indexes
    
  2. Security
    - Allow authenticated users to read roles
    - Allow users to read their own profiles
    - Restrict admin operations to users with admin role
*/

-- Drop ALL existing policies
DROP POLICY IF EXISTS "user_roles_select_policy" ON user_roles;
DROP POLICY IF EXISTS "user_profiles_select_policy" ON user_profiles;
DROP POLICY IF EXISTS "user_profiles_insert_policy" ON user_profiles;
DROP POLICY IF EXISTS "user_profiles_update_policy" ON user_profiles;
DROP POLICY IF EXISTS "anyone_can_read_roles" ON user_roles;
DROP POLICY IF EXISTS "users_can_read_own_profile" ON user_profiles;
DROP POLICY IF EXISTS "admins_can_insert_profiles" ON user_profiles;
DROP POLICY IF EXISTS "admins_can_update_profiles" ON user_profiles;
DROP POLICY IF EXISTS "Admins can do everything with user_roles" ON user_roles;
DROP POLICY IF EXISTS "Admins can do everything with user_profiles" ON user_profiles;
DROP POLICY IF EXISTS "Users can view their own profile" ON user_profiles;

-- Create new simplified policies for user_roles
CREATE POLICY "anyone_can_read_roles_new"
  ON user_roles
  FOR SELECT
  TO authenticated
  USING (true);

-- Create new simplified policies for user_profiles
CREATE POLICY "users_can_read_own_profile_new"
  ON user_profiles
  FOR SELECT
  TO authenticated
  USING (
    user_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM user_profiles up
      WHERE up.user_id = auth.uid()
      AND up.role_id IN (
        SELECT id FROM user_roles WHERE name = 'admin'
      )
    )
  );

CREATE POLICY "admins_can_insert_profiles_new"
  ON user_profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_profiles up
      WHERE up.user_id = auth.uid()
      AND up.role_id IN (
        SELECT id FROM user_roles WHERE name = 'admin'
      )
    )
  );

CREATE POLICY "admins_can_update_profiles_new"
  ON user_profiles
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_profiles up
      WHERE up.user_id = auth.uid()
      AND up.role_id IN (
        SELECT id FROM user_roles WHERE name = 'admin'
      )
    )
  );

-- Create index to improve policy performance
CREATE INDEX IF NOT EXISTS idx_user_profiles_user_id ON user_profiles(user_id);
CREATE INDEX IF NOT EXISTS idx_user_profiles_role_id ON user_profiles(role_id);
CREATE INDEX IF NOT EXISTS idx_user_roles_name ON user_roles(name);