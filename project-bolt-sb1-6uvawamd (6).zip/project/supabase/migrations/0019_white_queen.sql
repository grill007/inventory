/*
  # Fix admin policies and functions

  1. Changes
    - Drop existing policies
    - Create new optimized admin check function
    - Add new RLS policies for user management
    - Add necessary indexes
*/

-- Drop existing policies
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "profiles_read_v22" ON user_profiles;
  DROP POLICY IF EXISTS "profiles_insert_v22" ON user_profiles;
  DROP POLICY IF EXISTS "profiles_update_v22" ON user_profiles;
  DROP POLICY IF EXISTS "profiles_delete_v22" ON user_profiles;
  DROP POLICY IF EXISTS "roles_read_v22" ON user_roles;
END $$;

-- Create admin check function without recursion
CREATE OR REPLACE FUNCTION check_admin_access()
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 
    FROM user_profiles up
    JOIN user_roles ur ON up.role_id = ur.id
    WHERE up.user_id = auth.uid()
    AND ur.name = 'admin'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create new policies
CREATE POLICY "roles_read_v23"
  ON user_roles
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "profiles_read_v23"
  ON user_profiles
  FOR SELECT
  TO authenticated
  USING (
    user_id = auth.uid() OR 
    check_admin_access()
  );

CREATE POLICY "profiles_insert_v23"
  ON user_profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (check_admin_access());

CREATE POLICY "profiles_update_v23"
  ON user_profiles
  FOR UPDATE
  TO authenticated
  USING (check_admin_access());

CREATE POLICY "profiles_delete_v23"
  ON user_profiles
  FOR DELETE
  TO authenticated
  USING (check_admin_access());

-- Ensure indexes exist
CREATE INDEX IF NOT EXISTS idx_user_profiles_user_id ON user_profiles(user_id);
CREATE INDEX IF NOT EXISTS idx_user_profiles_role_id ON user_profiles(role_id);
CREATE INDEX IF NOT EXISTS idx_user_roles_name ON user_roles(name);
CREATE INDEX IF NOT EXISTS idx_user_profiles_user_role ON user_profiles(user_id, role_id);