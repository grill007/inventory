/*
  # Fix RLS policies with unique names and efficient admin check

  1. Changes
    - Drop existing policies
    - Create new admin check function with optimized query
    - Create new policies with unique names
    - Refresh indexes for performance

  2. Security
    - Maintain same security model with improved efficiency
    - Keep RLS enabled on all tables
    - Ensure admin users retain full access
*/

-- Drop existing policies
DROP POLICY IF EXISTS "roles_read_policy_v9" ON user_roles;
DROP POLICY IF EXISTS "profiles_read_policy_v9" ON user_profiles;
DROP POLICY IF EXISTS "profiles_insert_policy_v9" ON user_profiles;
DROP POLICY IF EXISTS "profiles_update_policy_v9" ON user_profiles;
DROP POLICY IF EXISTS "profiles_delete_policy_v9" ON user_profiles;

-- Create optimized admin check function
CREATE OR REPLACE FUNCTION is_admin_v2(user_uid uuid)
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 
    FROM user_profiles up
    JOIN user_roles ur ON up.role_id = ur.id
    WHERE up.user_id = user_uid
    AND ur.name = 'admin'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create new policies with unique names
CREATE POLICY "roles_read_policy_v20"
  ON user_roles
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "profiles_read_policy_v20"
  ON user_profiles
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid() OR is_admin_v2(auth.uid()));

CREATE POLICY "profiles_insert_policy_v20"
  ON user_profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (is_admin_v2(auth.uid()));

CREATE POLICY "profiles_update_policy_v20"
  ON user_profiles
  FOR UPDATE
  TO authenticated
  USING (is_admin_v2(auth.uid()));

CREATE POLICY "profiles_delete_policy_v20"
  ON user_profiles
  FOR DELETE
  TO authenticated
  USING (is_admin_v2(auth.uid()));

-- Refresh indexes
DROP INDEX IF EXISTS idx_user_profiles_user_id;
DROP INDEX IF EXISTS idx_user_profiles_role_id;
DROP INDEX IF EXISTS idx_user_roles_name;
DROP INDEX IF EXISTS idx_user_profiles_user_role;

CREATE INDEX idx_user_profiles_user_id ON user_profiles(user_id);
CREATE INDEX idx_user_profiles_role_id ON user_profiles(role_id);
CREATE INDEX idx_user_roles_name ON user_roles(name);
CREATE INDEX idx_user_profiles_user_role ON user_profiles(user_id, role_id);