/*
  # Fix user profiles policies

  1. Changes
    - Drop existing policies on user_profiles
    - Create separate policies for each operation
    - Simplify admin check logic to prevent recursion
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Admins can do everything with user_profiles" ON user_profiles;
DROP POLICY IF EXISTS "Users can view their own profile" ON user_profiles;

-- Create new policies
CREATE POLICY "Users can view their own profile"
  ON user_profiles
  FOR SELECT
  TO authenticated
  USING (
    user_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM user_profiles up
      WHERE up.user_id = auth.uid()
      AND up.role_id IN (
        SELECT id FROM user_roles WHERE name = 'admin'
      )
    )
  );

CREATE POLICY "Admins can insert profiles"
  ON user_profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_profiles up
      WHERE up.user_id = auth.uid()
      AND up.role_id IN (
        SELECT id FROM user_roles WHERE name = 'admin'
      )
    )
  );

CREATE POLICY "Admins can update profiles"
  ON user_profiles
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_profiles up
      WHERE up.user_id = auth.uid()
      AND up.role_id IN (
        SELECT id FROM user_roles WHERE name = 'admin'
      )
    )
  );

CREATE POLICY "Admins can delete profiles"
  ON user_profiles
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_profiles up
      WHERE up.user_id = auth.uid()
      AND up.role_id IN (
        SELECT id FROM user_roles WHERE name = 'admin'
      )
    )
  );