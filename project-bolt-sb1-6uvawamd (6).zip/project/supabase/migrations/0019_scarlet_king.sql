-- Drop existing policies
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "roles_read_v22" ON user_roles;
  DROP POLICY IF EXISTS "profiles_read_v22" ON user_profiles;
  DROP POLICY IF EXISTS "profiles_insert_v22" ON user_profiles;
  DROP POLICY IF EXISTS "profiles_update_v22" ON user_profiles;
  DROP POLICY IF EXISTS "profiles_delete_v22" ON user_profiles;
END $$;

-- Create simple policies without recursion
CREATE POLICY "roles_read_v23"
  ON user_roles
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "profiles_read_v23"
  ON user_profiles
  FOR SELECT
  TO authenticated
  USING (
    user_id = auth.uid() OR
    EXISTS (
      SELECT 1 
      FROM user_roles r
      WHERE r.id IN (
        SELECT role_id 
        FROM user_profiles 
        WHERE user_id = auth.uid()
      )
      AND r.name = 'admin'
    )
  );

CREATE POLICY "profiles_insert_v23"
  ON user_profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 
      FROM user_roles r
      WHERE r.id IN (
        SELECT role_id 
        FROM user_profiles 
        WHERE user_id = auth.uid()
      )
      AND r.name = 'admin'
    )
  );

CREATE POLICY "profiles_update_v23"
  ON user_profiles
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 
      FROM user_roles r
      WHERE r.id IN (
        SELECT role_id 
        FROM user_profiles 
        WHERE user_id = auth.uid()
      )
      AND r.name = 'admin'
    )
  );

CREATE POLICY "profiles_delete_v23"
  ON user_profiles
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 
      FROM user_roles r
      WHERE r.id IN (
        SELECT role_id 
        FROM user_profiles 
        WHERE user_id = auth.uid()
      )
      AND r.name = 'admin'
    )
  );

-- Refresh indexes
DROP INDEX IF EXISTS idx_user_profiles_user_id;
DROP INDEX IF EXISTS idx_user_profiles_role_id;
DROP INDEX IF EXISTS idx_user_roles_name;
DROP INDEX IF EXISTS idx_user_profiles_user_role;

CREATE INDEX idx_user_profiles_user_id ON user_profiles(user_id);
CREATE INDEX idx_user_profiles_role_id ON user_profiles(role_id);
CREATE INDEX idx_user_roles_name ON user_roles(name);
CREATE INDEX idx_user_profiles_user_role ON user_profiles(user_id, role_id);