/*
  # Simplify RLS policies

  1. Changes
    - Drop all existing policies
    - Create new simplified policies without recursive checks
    - Add efficient indexes
    
  2. Security
    - Maintain proper access control
    - Prevent policy recursion
    - Keep admin privileges secure
*/

-- Drop all existing policies
DROP POLICY IF EXISTS "anyone_can_read_roles" ON user_roles;
DROP POLICY IF EXISTS "users_can_read_own_profile" ON user_profiles;
DROP POLICY IF EXISTS "admins_can_insert_profiles" ON user_profiles;
DROP POLICY IF EXISTS "admins_can_update_profiles" ON user_profiles;

-- Create simple read-only policy for user_roles
CREATE POLICY "allow_read_roles"
  ON user_roles
  FOR SELECT
  TO authenticated
  USING (true);

-- Create policies for user_profiles with direct checks
CREATE POLICY "allow_read_profiles"
  ON user_profiles
  FOR SELECT
  TO authenticated
  USING (
    user_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE id IN (
        SELECT role_id FROM user_profiles
        WHERE user_id = auth.uid()
      )
      AND name = 'admin'
    )
  );

CREATE POLICY "allow_insert_profiles"
  ON user_profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE id IN (
        SELECT role_id FROM user_profiles
        WHERE user_id = auth.uid()
      )
      AND name = 'admin'
    )
  );

CREATE POLICY "allow_update_profiles"
  ON user_profiles
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE id IN (
        SELECT role_id FROM user_profiles
        WHERE user_id = auth.uid()
      )
      AND name = 'admin'
    )
  );

CREATE POLICY "allow_delete_profiles"
  ON user_profiles
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE id IN (
        SELECT role_id FROM user_profiles
        WHERE user_id = auth.uid()
      )
      AND name = 'admin'
    )
  );

-- Ensure indexes exist for performance
CREATE INDEX IF NOT EXISTS idx_user_profiles_user_id ON user_profiles(user_id);
CREATE INDEX IF NOT EXISTS idx_user_profiles_role_id ON user_profiles(role_id);
CREATE INDEX IF NOT EXISTS idx_user_roles_name ON user_roles(name);

-- Add composite index for common query pattern
CREATE INDEX IF NOT EXISTS idx_user_profiles_user_role 
  ON user_profiles(user_id, role_id);