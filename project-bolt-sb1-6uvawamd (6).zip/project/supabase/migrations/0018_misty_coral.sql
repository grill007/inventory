/*
  # Simplify policy management
  
  1. Changes
    - Drop all existing policies
    - Create new simplified policies without version numbers
    - Add optimized admin check function
    - Create necessary indexes
*/

-- Drop all existing policies
DO $$ 
BEGIN
  -- Drop policies from user_profiles
  DROP POLICY IF EXISTS "profiles_read_policy_v30" ON user_profiles;
  DROP POLICY IF EXISTS "profiles_insert_policy_v30" ON user_profiles;
  DROP POLICY IF EXISTS "profiles_update_policy_v30" ON user_profiles;
  DROP POLICY IF EXISTS "profiles_delete_policy_v30" ON user_profiles;
  
  -- Drop policies from user_roles
  DROP POLICY IF EXISTS "roles_read_policy_v30" ON user_roles;
END $$;

-- Create admin check function
CREATE OR REPLACE FUNCTION is_admin()
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 
    FROM user_profiles up
    JOIN user_roles ur ON up.role_id = ur.id
    WHERE up.user_id = auth.uid()
    AND ur.name = 'admin'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create simplified policies
CREATE POLICY "roles_read"
  ON user_roles
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "profiles_read"
  ON user_profiles
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid() OR is_admin());

CREATE POLICY "profiles_insert"
  ON user_profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (is_admin());

CREATE POLICY "profiles_update"
  ON user_profiles
  FOR UPDATE
  TO authenticated
  USING (is_admin());

CREATE POLICY "profiles_delete"
  ON user_profiles
  FOR DELETE
  TO authenticated
  USING (is_admin());

-- Ensure indexes exist
CREATE INDEX IF NOT EXISTS idx_user_profiles_user_id ON user_profiles(user_id);
CREATE INDEX IF NOT EXISTS idx_user_profiles_role_id ON user_profiles(role_id);
CREATE INDEX IF NOT EXISTS idx_user_roles_name ON user_roles(name);
CREATE INDEX IF NOT EXISTS idx_user_profiles_user_role ON user_profiles(user_id, role_id);