/*
  # 管理者システムの実装

  1. 新しいテーブル
    - `user_roles` - ユーザーの役割を管理
    - `user_profiles` - ユーザーの追加情報
    - `access_logs` - システムアクセスログ
    - `system_settings` - システム設定

  2. セキュリティ
    - すべてのテーブルでRLSを有効化
    - 管理者のみが全データにアクセス可能
    - 一般ユーザーは自身のデータのみアクセス可能
*/

-- ユーザーロールテーブル
CREATE TABLE user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  created_at timestamptz DEFAULT now()
);

-- 初期ロールの追加
INSERT INTO user_roles (name, description) VALUES
  ('admin', '管理者'),
  ('user', '一般ユーザー');

-- ユーザープロファイルテーブル
CREATE TABLE user_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  role_id uuid REFERENCES user_roles(id) NOT NULL,
  display_name text NOT NULL,
  department text,
  is_active boolean DEFAULT true,
  last_login_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- アクセスログテーブル
CREATE TABLE access_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  action text NOT NULL,
  resource text NOT NULL,
  ip_address text,
  user_agent text,
  created_at timestamptz DEFAULT now()
);

-- システム設定テーブル
CREATE TABLE system_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key text UNIQUE NOT NULL,
  value jsonb NOT NULL,
  description text,
  updated_by uuid REFERENCES auth.users(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- RLSの有効化
ALTER TABLE user_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE access_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE system_settings ENABLE ROW LEVEL SECURITY;

-- 管理者用ポリシー
CREATE POLICY "Admins can do everything with user_roles"
  ON user_roles
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_profiles up
      WHERE up.user_id = auth.uid()
      AND up.role_id = (SELECT id FROM user_roles WHERE name = 'admin')
    )
  );

CREATE POLICY "Admins can do everything with user_profiles"
  ON user_profiles
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_profiles up
      WHERE up.user_id = auth.uid()
      AND up.role_id = (SELECT id FROM user_roles WHERE name = 'admin')
    )
  );

CREATE POLICY "Admins can view all access_logs"
  ON access_logs
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_profiles up
      WHERE up.user_id = auth.uid()
      AND up.role_id = (SELECT id FROM user_roles WHERE name = 'admin')
    )
  );

CREATE POLICY "Admins can manage system_settings"
  ON system_settings
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_profiles up
      WHERE up.user_id = auth.uid()
      AND up.role_id = (SELECT id FROM user_roles WHERE name = 'admin')
    )
  );

-- 一般ユーザー用ポリシー
CREATE POLICY "Users can view their own profile"
  ON user_profiles
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can view their own access_logs"
  ON access_logs
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

-- スーパー管理者の作成
WITH admin_role AS (
  SELECT id FROM user_roles WHERE name = 'admin'
)
INSERT INTO user_profiles (user_id, role_id, display_name)
SELECT 
  id,
  (SELECT id FROM admin_role),
  'スーパー管理者'
FROM auth.users
WHERE email = 'superadmin';

-- パスワードの更新
UPDATE auth.users
SET encrypted_password = crypt('gripgrip2', gen_salt('bf'))
WHERE email = 'superadmin';