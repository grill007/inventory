/*
  # Fix user role and profile policies

  1. Changes
    - Drop all existing policies
    - Create new simplified policies with unique names
    - Add performance indexes
    
  2. Security
    - Maintain proper access control
    - Prevent infinite recursion
    - Optimize query performance
*/

-- Drop ALL existing policies
DROP POLICY IF EXISTS "read_roles" ON user_roles;
DROP POLICY IF EXISTS "read_own_profile" ON user_profiles;
DROP POLICY IF EXISTS "admin_insert_profile" ON user_profiles;
DROP POLICY IF EXISTS "admin_update_profile" ON user_profiles;
DROP POLICY IF EXISTS "admin_delete_profile" ON user_profiles;

-- Create simple read-only policy for user_roles with unique name
CREATE POLICY "roles_read_policy_v6"
  ON user_roles
  FOR SELECT
  TO authenticated
  USING (true);

-- Create simplified non-recursive policies for user_profiles
CREATE POLICY "profiles_read_policy_v6"
  ON user_profiles
  FOR SELECT
  TO authenticated
  USING (
    user_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM user_roles r
      WHERE r.id IN (
        SELECT role_id FROM user_profiles
        WHERE user_id = auth.uid()
      )
      AND r.name = 'admin'
    )
  );

CREATE POLICY "profiles_insert_policy_v6"
  ON user_profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_roles r
      WHERE r.id IN (
        SELECT role_id FROM user_profiles
        WHERE user_id = auth.uid()
      )
      AND r.name = 'admin'
    )
  );

CREATE POLICY "profiles_update_policy_v6"
  ON user_profiles
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles r
      WHERE r.id IN (
        SELECT role_id FROM user_profiles
        WHERE user_id = auth.uid()
      )
      AND r.name = 'admin'
    )
  );

CREATE POLICY "profiles_delete_policy_v6"
  ON user_profiles
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles r
      WHERE r.id IN (
        SELECT role_id FROM user_profiles
        WHERE user_id = auth.uid()
      )
      AND r.name = 'admin'
    )
  );

-- Ensure indexes exist for performance
CREATE INDEX IF NOT EXISTS idx_user_profiles_user_id ON user_profiles(user_id);
CREATE INDEX IF NOT EXISTS idx_user_profiles_role_id ON user_profiles(role_id);
CREATE INDEX IF NOT EXISTS idx_user_roles_name ON user_roles(name);
CREATE INDEX IF NOT EXISTS idx_user_profiles_user_role ON user_profiles(user_id, role_id);