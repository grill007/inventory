-- Drop existing policies
DROP POLICY IF EXISTS "read_roles" ON user_roles;
DROP POLICY IF EXISTS "read_own_profile" ON user_profiles;
DROP POLICY IF EXISTS "admin_insert_profile" ON user_profiles;
DROP POLICY IF EXISTS "admin_update_profile" ON user_profiles;
DROP POLICY IF EXISTS "admin_delete_profile" ON user_profiles;

-- Create simple read-only policy for user_roles
CREATE POLICY "allow_read_roles"
  ON user_roles
  FOR SELECT
  TO authenticated
  USING (true);

-- Create base profile policy for all users
CREATE POLICY "allow_read_own_profile"
  ON user_profiles
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

-- Create admin-specific policies using a subquery
CREATE POLICY "allow_admin_read_all"
  ON user_profiles
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 
      FROM user_profiles up
      INNER JOIN user_roles ur ON up.role_id = ur.id
      WHERE up.user_id = auth.uid() 
      AND ur.name = 'admin'
    )
  );

CREATE POLICY "allow_admin_insert"
  ON user_profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 
      FROM user_profiles up
      INNER JOIN user_roles ur ON up.role_id = ur.id
      WHERE up.user_id = auth.uid() 
      AND ur.name = 'admin'
    )
  );

CREATE POLICY "allow_admin_update"
  ON user_profiles
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 
      FROM user_profiles up
      INNER JOIN user_roles ur ON up.role_id = ur.id
      WHERE up.user_id = auth.uid() 
      AND ur.name = 'admin'
    )
  );

CREATE POLICY "allow_admin_delete"
  ON user_profiles
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 
      FROM user_profiles up
      INNER JOIN user_roles ur ON up.role_id = ur.id
      WHERE up.user_id = auth.uid() 
      AND ur.name = 'admin'
    )
  );

-- Reset admin user
DO $$
DECLARE
  v_admin_role_id uuid;
  v_admin_user_id uuid;
BEGIN
  -- Get admin role ID
  SELECT id INTO v_admin_role_id
  FROM user_roles
  WHERE name = 'admin';

  -- Get admin user ID
  SELECT id INTO v_admin_user_id
  FROM auth.users
  WHERE email = 'shiraishi@infogrip.net';

  -- Update admin user password
  UPDATE auth.users
  SET 
    encrypted_password = crypt('icecream11', gen_salt('bf')),
    email_confirmed_at = now(),
    updated_at = now()
  WHERE id = v_admin_user_id;

  -- Ensure admin profile exists
  INSERT INTO user_profiles (user_id, role_id, display_name)
  VALUES (v_admin_user_id, v_admin_role_id, 'システム管理者')
  ON CONFLICT (user_id) DO UPDATE
  SET role_id = v_admin_role_id;
END $$;