/*
  # Fix admin access and policies

  1. Changes
    - Drop all existing policies to start fresh
    - Create simplified policies for admin access
    - Add necessary indexes
    
  2. Security
    - Allow admins to read all profiles
    - Allow users to read their own profile
    - Allow admins to manage other profiles
*/

-- Drop existing policies
DROP POLICY IF EXISTS "read_roles" ON user_roles;
DROP POLICY IF EXISTS "read_own_profile" ON user_profiles;
DROP POLICY IF EXISTS "admin_insert_profile" ON user_profiles;
DROP POLICY IF EXISTS "admin_update_profile" ON user_profiles;
DROP POLICY IF EXISTS "admin_delete_profile" ON user_profiles;

-- Create simple policies for user_roles
CREATE POLICY "allow_read_roles"
  ON user_roles
  FOR SELECT
  TO authenticated
  USING (true);

-- Create simplified policies for user_profiles
CREATE POLICY "allow_read_profiles"
  ON user_profiles
  FOR SELECT
  TO authenticated
  USING (
    user_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE id = role_id
      AND name = 'admin'
    )
  );

CREATE POLICY "allow_admin_manage_profiles"
  ON user_profiles
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE id = role_id
      AND name = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE id = role_id
      AND name = 'admin'
    )
  );

-- Ensure admin user exists
DO $$
DECLARE
  v_admin_role_id uuid;
  v_admin_user_id uuid;
BEGIN
  -- Get admin role ID
  SELECT id INTO v_admin_role_id
  FROM user_roles
  WHERE name = 'admin';

  -- Get admin user ID
  SELECT id INTO v_admin_user_id
  FROM auth.users
  WHERE email = 'shiraishi@infogrip.net';

  -- Ensure admin profile exists
  INSERT INTO user_profiles (user_id, role_id, display_name)
  VALUES (v_admin_user_id, v_admin_role_id, 'システム管理者')
  ON CONFLICT (user_id) DO UPDATE
  SET role_id = v_admin_role_id;
END $$;