/*
  # Product Images Implementation

  1. New Tables
    - `product_images`
      - `id` (uuid, primary key)
      - `product_id` (uuid, references products)
      - `url` (text)
      - `is_main` (boolean)
      - `user_id` (uuid, references auth.users)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on product_images table
    - Add policies for CRUD operations
    - Create indexes for performance

  3. Changes
    - Add cascade delete for product images when product is deleted
*/

-- Create product_images table if it doesn't exist
CREATE TABLE IF NOT EXISTS product_images (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid REFERENCES products(id) ON DELETE CASCADE,
  url text NOT NULL,
  is_main boolean DEFAULT false,
  user_id uuid REFERENCES auth.users(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE product_images ENABLE ROW LEVEL SECURITY;

-- Create policies with unique names
CREATE POLICY "product_images_select_policy"
  ON product_images
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "product_images_insert_policy"
  ON product_images
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "product_images_update_policy"
  ON product_images
  FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "product_images_delete_policy"
  ON product_images
  FOR DELETE
  TO authenticated
  USING (user_id = auth.uid());

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_product_images_product_id ON product_images(product_id);
CREATE INDEX IF NOT EXISTS idx_product_images_user_id ON product_images(user_id);
CREATE INDEX IF NOT EXISTS idx_product_images_is_main ON product_images(is_main);

-- Create storage bucket for product images if it doesn't exist
INSERT INTO storage.buckets (id, name)
SELECT 'product-images', 'product-images'
WHERE NOT EXISTS (
  SELECT 1 FROM storage.buckets WHERE id = 'product-images'
);

-- Create storage policies with unique names
CREATE POLICY "storage_product_images_insert_policy"
  ON storage.objects
  FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id = 'product-images' AND
    auth.uid() = owner
  );

CREATE POLICY "storage_product_images_select_policy"
  ON storage.objects
  FOR SELECT
  TO authenticated
  USING (bucket_id = 'product-images');