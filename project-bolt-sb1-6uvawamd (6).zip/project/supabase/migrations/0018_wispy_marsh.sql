/*
  # Fix recursive policies
  
  1. Changes
    - Remove recursive admin checks
    - Simplify policy logic
    - Add materialized admin role cache
*/

-- First, drop all existing policies
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "roles_read" ON user_roles;
  DROP POLICY IF EXISTS "profiles_read" ON user_profiles;
  DROP POLICY IF EXISTS "profiles_insert" ON user_profiles;
  DROP POLICY IF EXISTS "profiles_update" ON user_profiles;
  DROP POLICY IF EXISTS "profiles_delete" ON user_profiles;
END $$;

-- Create a materialized view for admin users to avoid recursion
CREATE MATERIALIZED VIEW admin_users AS
SELECT DISTINCT up.user_id
FROM user_profiles up
JOIN user_roles ur ON up.role_id = ur.id
WHERE ur.name = 'admin';

-- Create index on the materialized view
CREATE UNIQUE INDEX admin_users_user_id_idx ON admin_users (user_id);

-- Create function to refresh admin users
CREATE OR REPLACE FUNCTION refresh_admin_users()
RETURNS TRIGGER AS $$
BEGIN
  REFRESH MATERIALIZED VIEW CONCURRENTLY admin_users;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Create triggers to refresh admin users
CREATE TRIGGER refresh_admin_users_on_profile_change
  AFTER INSERT OR UPDATE OR DELETE ON user_profiles
  FOR EACH STATEMENT
  EXECUTE FUNCTION refresh_admin_users();

CREATE TRIGGER refresh_admin_users_on_role_change
  AFTER UPDATE OF name ON user_roles
  FOR EACH STATEMENT
  EXECUTE FUNCTION refresh_admin_users();

-- Create simplified policies using materialized view
CREATE POLICY "roles_read"
  ON user_roles
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "profiles_read"
  ON user_profiles
  FOR SELECT
  TO authenticated
  USING (
    user_id = auth.uid() OR 
    EXISTS (SELECT 1 FROM admin_users WHERE user_id = auth.uid())
  );

CREATE POLICY "profiles_insert"
  ON user_profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (SELECT 1 FROM admin_users WHERE user_id = auth.uid())
  );

CREATE POLICY "profiles_update"
  ON user_profiles
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (SELECT 1 FROM admin_users WHERE user_id = auth.uid())
  );

CREATE POLICY "profiles_delete"
  ON user_profiles
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (SELECT 1 FROM admin_users WHERE user_id = auth.uid())
  );

-- Initial refresh of admin users view
REFRESH MATERIALIZED VIEW admin_users;