/*
  # Fix RLS policies with optimized admin check
  
  1. Changes
    - Drop existing policies
    - Create optimized admin check function
    - Create simplified policies with unique names
    - Add performance optimizations
  
  2. Benefits
    - Prevents infinite recursion
    - Improves query performance
    - Maintains security rules
*/

-- Drop all existing policies
DO $$ 
BEGIN
  -- Drop policies from user_profiles
  DROP POLICY IF EXISTS "profiles_read" ON user_profiles;
  DROP POLICY IF EXISTS "profiles_insert" ON user_profiles;
  DROP POLICY IF EXISTS "profiles_update" ON user_profiles;
  DROP POLICY IF EXISTS "profiles_delete" ON user_profiles;
  DROP POLICY IF EXISTS "roles_read" ON user_roles;
END $$;

-- Create admin check function with unique name
CREATE OR REPLACE FUNCTION is_admin_v19()
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 
    FROM user_profiles up
    JOIN user_roles ur ON up.role_id = ur.id
    WHERE up.user_id = auth.uid()
    AND ur.name = 'admin'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create simplified policies with unique names
CREATE POLICY "roles_read_v19"
  ON user_roles
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "profiles_read_v19"
  ON user_profiles
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid() OR is_admin_v19());

CREATE POLICY "profiles_insert_v19"
  ON user_profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (is_admin_v19());

CREATE POLICY "profiles_update_v19"
  ON user_profiles
  FOR UPDATE
  TO authenticated
  USING (is_admin_v19());

CREATE POLICY "profiles_delete_v19"
  ON user_profiles
  FOR DELETE
  TO authenticated
  USING (is_admin_v19());

-- Ensure indexes exist
DO $$ 
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_user_profiles_user_id') THEN
    CREATE INDEX idx_user_profiles_user_id ON user_profiles(user_id);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_user_profiles_role_id') THEN
    CREATE INDEX idx_user_profiles_role_id ON user_profiles(role_id);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_user_roles_name') THEN
    CREATE INDEX idx_user_roles_name ON user_roles(name);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_user_profiles_user_role') THEN
    CREATE INDEX idx_user_profiles_user_role ON user_profiles(user_id, role_id);
  END IF;
END $$;