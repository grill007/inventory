/*
  # Fix RLS policies with optimized admin check

  1. Changes
    - Drop existing policies
    - Create a new optimized admin check function
    - Create new policies with direct role checks
    - Optimize indexes for better performance

  2. Security
    - Maintain proper access control
    - Prevent unauthorized access
    - Ensure data isolation
*/

-- Drop existing policies
DROP POLICY IF EXISTS "roles_read_policy_v21" ON user_roles;
DROP POLICY IF EXISTS "profiles_read_policy_v21" ON user_profiles;
DROP POLICY IF EXISTS "profiles_insert_policy_v21" ON user_profiles;
DROP POLICY IF EXISTS "profiles_update_policy_v21" ON user_profiles;
DROP POLICY IF EXISTS "profiles_delete_policy_v21" ON user_profiles;

-- Create optimized admin check function
CREATE OR REPLACE FUNCTION check_admin_role_v1(check_user_id uuid)
RETURNS boolean AS $$
DECLARE
  is_admin boolean;
BEGIN
  SELECT EXISTS (
    SELECT 1 
    FROM user_roles r
    INNER JOIN user_profiles p ON p.role_id = r.id
    WHERE p.user_id = check_user_id
    AND r.name = 'admin'
  ) INTO is_admin;
  
  RETURN is_admin;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create new policies with unique names
CREATE POLICY "roles_read_policy_v40"
  ON user_roles
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "profiles_read_policy_v40"
  ON user_profiles
  FOR SELECT
  TO authenticated
  USING (
    user_id = auth.uid() OR
    check_admin_role_v1(auth.uid())
  );

CREATE POLICY "profiles_insert_policy_v40"
  ON user_profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (check_admin_role_v1(auth.uid()));

CREATE POLICY "profiles_update_policy_v40"
  ON user_profiles
  FOR UPDATE
  TO authenticated
  USING (check_admin_role_v1(auth.uid()));

CREATE POLICY "profiles_delete_policy_v40"
  ON user_profiles
  FOR DELETE
  TO authenticated
  USING (check_admin_role_v1(auth.uid()));

-- Optimize indexes
DO $$ 
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_user_profiles_user_id') THEN
    CREATE INDEX idx_user_profiles_user_id ON user_profiles(user_id);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_user_profiles_role_id') THEN
    CREATE INDEX idx_user_profiles_role_id ON user_profiles(role_id);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_user_roles_name') THEN
    CREATE INDEX idx_user_roles_name ON user_roles(name);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_user_profiles_user_role') THEN
    CREATE INDEX idx_user_profiles_user_role ON user_profiles(user_id, role_id);
  END IF;
END $$;