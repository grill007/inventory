/*
  # Fix RLS policies to prevent recursion

  1. Changes
    - Drop all existing policies
    - Create new non-recursive policies
    - Add performance indexes
    
  2. Security
    - Allow authenticated users to read roles
    - Allow users to read their own profiles
    - Allow admins to manage other profiles
*/

-- Drop ALL existing policies
DROP POLICY IF EXISTS "anyone_can_read_roles_new" ON user_roles;
DROP POLICY IF EXISTS "users_can_read_own_profile_new" ON user_profiles;
DROP POLICY IF EXISTS "admins_can_insert_profiles_new" ON user_profiles;
DROP POLICY IF EXISTS "admins_can_update_profiles_new" ON user_profiles;
DROP POLICY IF EXISTS "allow_read_roles" ON user_roles;
DROP POLICY IF EXISTS "allow_read_profiles" ON user_profiles;
DROP POLICY IF EXISTS "allow_insert_profiles" ON user_profiles;
DROP POLICY IF EXISTS "allow_update_profiles" ON user_profiles;
DROP POLICY IF EXISTS "allow_delete_profiles" ON user_profiles;

-- Create simple read-only policy for user_roles
CREATE POLICY "read_roles"
  ON user_roles
  FOR SELECT
  TO authenticated
  USING (true);

-- Create non-recursive policies for user_profiles
CREATE POLICY "read_own_profile"
  ON user_profiles
  FOR SELECT
  TO authenticated
  USING (
    user_id = auth.uid() OR
    role_id IN (
      SELECT id FROM user_roles 
      WHERE name = 'admin'
    )
  );

CREATE POLICY "admin_insert_profile"
  ON user_profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (
    role_id IN (
      SELECT id FROM user_roles 
      WHERE name = 'admin'
    )
  );

CREATE POLICY "admin_update_profile"
  ON user_profiles
  FOR UPDATE
  TO authenticated
  USING (
    role_id IN (
      SELECT id FROM user_roles 
      WHERE name = 'admin'
    )
  );

CREATE POLICY "admin_delete_profile"
  ON user_profiles
  FOR DELETE
  TO authenticated
  USING (
    role_id IN (
      SELECT id FROM user_roles 
      WHERE name = 'admin'
    )
  );

-- Ensure indexes exist for performance
CREATE INDEX IF NOT EXISTS idx_user_profiles_user_id ON user_profiles(user_id);
CREATE INDEX IF NOT EXISTS idx_user_profiles_role_id ON user_profiles(role_id);
CREATE INDEX IF NOT EXISTS idx_user_roles_name ON user_roles(name);
CREATE INDEX IF NOT EXISTS idx_user_profiles_user_role ON user_profiles(user_id, role_id);