/*
  # Fix policies and admin setup

  1. Changes
    - Simplify policies to prevent recursion
    - Update admin user credentials
    - Fix role assignments
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Users can view their own profile" ON user_profiles;
DROP POLICY IF EXISTS "Admins can insert profiles" ON user_profiles;
DROP POLICY IF EXISTS "Admins can update profiles" ON user_profiles;
DROP POLICY IF EXISTS "Admins can delete profiles" ON user_profiles;

-- Create simplified policies
CREATE POLICY "Allow all operations for admin"
  ON user_profiles
  TO authenticated
  USING (
    role_id IN (SELECT id FROM user_roles WHERE name = 'admin')
    OR user_id = auth.uid()
  );

-- Update admin user and ensure proper role assignment
DO $$
DECLARE
  admin_role_id uuid;
  admin_user_id uuid;
BEGIN
  -- Get admin role ID
  SELECT id INTO admin_role_id FROM user_roles WHERE name = 'admin';
  
  -- Get admin user ID
  SELECT id INTO admin_user_id FROM auth.users WHERE email = 'shiraishi@infogrip.net';

  -- Update admin user if needed
  IF admin_user_id IS NULL THEN
    -- Create admin user if doesn't exist
    INSERT INTO auth.users (
      email,
      encrypted_password,
      email_confirmed_at,
      raw_app_meta_data,
      raw_user_meta_data
    ) VALUES (
      'shiraishi@infogrip.net',
      crypt('gripgrip2', gen_salt('bf')),
      now(),
      '{"provider": "email", "providers": ["email"]}',
      '{}'
    )
    RETURNING id INTO admin_user_id;
  END IF;

  -- Ensure admin user profile exists
  INSERT INTO user_profiles (user_id, role_id, display_name)
  VALUES (admin_user_id, admin_role_id, 'システム管理者')
  ON CONFLICT (user_id) 
  DO UPDATE SET role_id = admin_role_id;
END $$;