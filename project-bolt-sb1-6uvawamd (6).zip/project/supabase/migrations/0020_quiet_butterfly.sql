/*
  # Fix admin role policies

  1. Changes
    - Drop existing policies
    - Create new optimized policies with unique names
    - Add proper indexes
    - Avoid recursive checks
    - Use direct role checks
*/

-- Drop existing policies
DROP POLICY IF EXISTS "roles_read_policy_v11" ON user_roles;
DROP POLICY IF EXISTS "profiles_read_policy_v11" ON user_profiles;
DROP POLICY IF EXISTS "profiles_insert_policy_v11" ON user_profiles;
DROP POLICY IF EXISTS "profiles_update_policy_v11" ON user_profiles;
DROP POLICY IF EXISTS "profiles_delete_policy_v11" ON user_profiles;

-- Create simple read-only policy for user_roles with unique name
CREATE POLICY "roles_read_policy_v12"
  ON user_roles
  FOR SELECT
  TO authenticated
  USING (true);

-- Create non-recursive policies for user_profiles with unique names
CREATE POLICY "profiles_read_policy_v12"
  ON user_profiles
  FOR SELECT
  TO authenticated
  USING (
    user_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM user_roles r
      WHERE r.id = user_profiles.role_id
      AND r.name = 'admin'
    )
  );

CREATE POLICY "profiles_insert_policy_v12"
  ON user_profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_roles r
      WHERE r.id = NEW.role_id
      AND r.name = 'admin'
    )
  );

CREATE POLICY "profiles_update_policy_v12"
  ON user_profiles
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles r
      WHERE r.id = user_profiles.role_id
      AND r.name = 'admin'
    )
  );

CREATE POLICY "profiles_delete_policy_v12"
  ON user_profiles
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles r
      WHERE r.id = user_profiles.role_id
      AND r.name = 'admin'
    )
  );

-- Create indexes if they don't exist
DO $$ 
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_user_profiles_user_id') THEN
    CREATE INDEX idx_user_profiles_user_id ON user_profiles(user_id);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_user_profiles_role_id') THEN
    CREATE INDEX idx_user_profiles_role_id ON user_profiles(role_id);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_user_roles_name') THEN
    CREATE INDEX idx_user_roles_name ON user_roles(name);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_user_profiles_user_role') THEN
    CREATE INDEX idx_user_profiles_user_role ON user_profiles(user_id, role_id);
  END IF;
END $$;