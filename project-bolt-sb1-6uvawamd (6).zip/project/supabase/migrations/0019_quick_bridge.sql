/*
  # Fix admin policies and functions

  1. Changes
    - Drop existing policies that may cause recursion
    - Create new optimized admin check function
    - Add new RLS policies for user management
    - Ensure proper indexing

  2. Security
    - Maintain RLS protection
    - Prevent infinite recursion
    - Keep admin-only access for sensitive operations
*/

-- Drop existing policies
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "profiles_read" ON user_profiles;
  DROP POLICY IF EXISTS "profiles_insert" ON user_profiles;
  DROP POLICY IF EXISTS "profiles_update" ON user_profiles;
  DROP POLICY IF EXISTS "profiles_delete" ON user_profiles;
  DROP POLICY IF EXISTS "roles_read" ON user_roles;
END $$;

-- Create optimized admin check function
CREATE OR REPLACE FUNCTION is_admin_v22()
RETURNS boolean AS $$
DECLARE
  admin_role_id uuid;
BEGIN
  -- Get admin role ID directly
  SELECT id INTO admin_role_id 
  FROM user_roles 
  WHERE name = 'admin' 
  LIMIT 1;
  
  -- Check if user has admin role
  RETURN EXISTS (
    SELECT 1 
    FROM user_profiles 
    WHERE user_id = auth.uid() 
    AND role_id = admin_role_id
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create new policies
CREATE POLICY "roles_read_v22"
  ON user_roles
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "profiles_read_v22"
  ON user_profiles
  FOR SELECT
  TO authenticated
  USING (
    user_id = auth.uid() OR 
    (SELECT is_admin_v22())
  );

CREATE POLICY "profiles_insert_v22"
  ON user_profiles
  FOR INSERT
  TO authenticated
  WITH CHECK ((SELECT is_admin_v22()));

CREATE POLICY "profiles_update_v22"
  ON user_profiles
  FOR UPDATE
  TO authenticated
  USING ((SELECT is_admin_v22()));

CREATE POLICY "profiles_delete_v22"
  ON user_profiles
  FOR DELETE
  TO authenticated
  USING ((SELECT is_admin_v22()));

-- Ensure indexes exist
DO $$ 
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_user_profiles_user_id') THEN
    CREATE INDEX idx_user_profiles_user_id ON user_profiles(user_id);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_user_profiles_role_id') THEN
    CREATE INDEX idx_user_profiles_role_id ON user_profiles(role_id);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_user_roles_name') THEN
    CREATE INDEX idx_user_roles_name ON user_roles(name);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_user_profiles_user_role') THEN
    CREATE INDEX idx_user_profiles_user_role ON user_profiles(user_id, role_id);
  END IF;
END $$;