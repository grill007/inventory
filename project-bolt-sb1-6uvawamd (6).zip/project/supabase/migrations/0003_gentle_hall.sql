/*
  # Add customers table and update products table

  1. New Tables
    - `customers`
      - `id` (uuid, primary key)
      - `name` (text)
      - `name_kana` (text)
      - `postal_code` (text)
      - `address` (text)
      - `phone` (text)
      - `email` (text)
      - `notes` (text)
      - `user_id` (uuid, references auth.users)
      - `created_at` (timestamptz)

  2. Changes
    - Add `customer_id` column to `products` table
    - Add foreign key constraint to link products with customers

  3. Security
    - Enable RLS on `customers` table
    - Add policies for authenticated users to manage their own customer data
*/

-- Create customers table
CREATE TABLE IF NOT EXISTS customers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  name_kana text NOT NULL,
  postal_code text NOT NULL,
  address text NOT NULL,
  phone text NOT NULL,
  email text NOT NULL,
  notes text,
  user_id uuid REFERENCES auth.users(id) NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Add customer_id to products
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'products' AND column_name = 'customer_id'
  ) THEN
    ALTER TABLE products ADD COLUMN customer_id uuid REFERENCES customers(id);
  END IF;
END $$;

-- Enable RLS
ALTER TABLE customers ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can view their own customers"
  ON customers
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own customers"
  ON customers
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own customers"
  ON customers
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own customers"
  ON customers
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);