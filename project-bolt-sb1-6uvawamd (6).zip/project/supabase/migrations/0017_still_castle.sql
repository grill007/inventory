/*
  # Update user management policies and optimize performance

  1. Changes
    - Drop existing policies in correct order
    - Create new admin check function
    - Create new simplified policies
    - Optimize indexes

  2. Security
    - Maintain proper access control
    - Prevent infinite recursion
    - Ensure data isolation
*/

-- First drop all existing policies that might depend on the function
DROP POLICY IF EXISTS "profiles_read_policy_v10" ON user_profiles;
DROP POLICY IF EXISTS "profiles_insert_policy_v10" ON user_profiles;
DROP POLICY IF EXISTS "profiles_update_policy_v10" ON user_profiles;
DROP POLICY IF EXISTS "profiles_delete_policy_v10" ON user_profiles;
DROP POLICY IF EXISTS "roles_read_policy_v21" ON user_roles;
DROP POLICY IF EXISTS "profiles_read_policy_v21" ON user_profiles;
DROP POLICY IF EXISTS "profiles_insert_policy_v21" ON user_profiles;
DROP POLICY IF EXISTS "profiles_update_policy_v21" ON user_profiles;
DROP POLICY IF EXISTS "profiles_delete_policy_v21" ON user_profiles;

-- Now we can safely drop and recreate the function
DROP FUNCTION IF EXISTS check_is_admin(uuid);

-- Create new admin check function
CREATE OR REPLACE FUNCTION check_is_admin_v2(check_user_id uuid)
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 
    FROM user_profiles up
    JOIN user_roles ur ON up.role_id = ur.id
    WHERE up.user_id = check_user_id
    AND ur.name = 'admin'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create new policies with unique names
CREATE POLICY "roles_read_policy_v30"
  ON user_roles
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "profiles_read_policy_v30"
  ON user_profiles
  FOR SELECT
  TO authenticated
  USING (
    user_id = auth.uid() OR
    check_is_admin_v2(auth.uid())
  );

CREATE POLICY "profiles_insert_policy_v30"
  ON user_profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (check_is_admin_v2(auth.uid()));

CREATE POLICY "profiles_update_policy_v30"
  ON user_profiles
  FOR UPDATE
  TO authenticated
  USING (check_is_admin_v2(auth.uid()));

CREATE POLICY "profiles_delete_policy_v30"
  ON user_profiles
  FOR DELETE
  TO authenticated
  USING (check_is_admin_v2(auth.uid()));

-- Optimize indexes
DO $$ 
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_user_profiles_user_id') THEN
    CREATE INDEX idx_user_profiles_user_id ON user_profiles(user_id);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_user_profiles_role_id') THEN
    CREATE INDEX idx_user_profiles_role_id ON user_profiles(role_id);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_user_roles_name') THEN
    CREATE INDEX idx_user_roles_name ON user_roles(name);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_user_profiles_user_role') THEN
    CREATE INDEX idx_user_profiles_user_role ON user_profiles(user_id, role_id);
  END IF;
END $$;