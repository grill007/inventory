/*
  # Update RLS policies and add product images support

  1. Changes
    - Drop existing policies
    - Create new simplified policies with unique names
    - Add product images table and relations
    - Add performance indexes
*/

-- Create product_images table
CREATE TABLE IF NOT EXISTS product_images (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid REFERENCES products(id) ON DELETE CASCADE,
  url text NOT NULL,
  is_main boolean DEFAULT false,
  user_id uuid REFERENCES auth.users(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS on product_images
ALTER TABLE product_images ENABLE ROW LEVEL SECURITY;

-- Drop existing policies
DROP POLICY IF EXISTS "roles_read_v29" ON user_roles;
DROP POLICY IF EXISTS "profiles_read_v29" ON user_profiles;
DROP POLICY IF EXISTS "profiles_insert_v29" ON user_profiles;
DROP POLICY IF EXISTS "profiles_update_v29" ON user_profiles;
DROP POLICY IF EXISTS "profiles_delete_v29" ON user_profiles;

-- Create simple read-only policy for user_roles
CREATE POLICY "roles_read_v30"
  ON user_roles
  FOR SELECT
  TO authenticated
  USING (true);

-- Create direct policies for user_profiles
CREATE POLICY "profiles_read_v30"
  ON user_profiles
  FOR SELECT
  TO authenticated
  USING (
    user_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE id = user_profiles.role_id
      AND name = 'admin'
    )
  );

CREATE POLICY "profiles_insert_v30"
  ON user_profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_profiles up
      JOIN user_roles ur ON up.role_id = ur.id
      WHERE up.user_id = auth.uid()
      AND ur.name = 'admin'
    )
  );

CREATE POLICY "profiles_update_v30"
  ON user_profiles
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_profiles up
      JOIN user_roles ur ON up.role_id = ur.id
      WHERE up.user_id = auth.uid()
      AND ur.name = 'admin'
    )
  );

CREATE POLICY "profiles_delete_v30"
  ON user_profiles
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_profiles up
      JOIN user_roles ur ON up.role_id = ur.id
      WHERE up.user_id = auth.uid()
      AND ur.name = 'admin'
    )
  );

-- Create policies for product_images
CREATE POLICY "product_images_select"
  ON product_images
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "product_images_insert"
  ON product_images
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "product_images_update"
  ON product_images
  FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "product_images_delete"
  ON product_images
  FOR DELETE
  TO authenticated
  USING (user_id = auth.uid());

-- Ensure indexes exist for performance
DO $$ 
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_user_profiles_user_id') THEN
    CREATE INDEX idx_user_profiles_user_id ON user_profiles(user_id);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_user_profiles_role_id') THEN
    CREATE INDEX idx_user_profiles_role_id ON user_profiles(role_id);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_user_roles_name') THEN
    CREATE INDEX idx_user_roles_name ON user_roles(name);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_user_profiles_user_role') THEN
    CREATE INDEX idx_user_profiles_user_role ON user_profiles(user_id, role_id);
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_product_images_product_id') THEN
    CREATE INDEX idx_product_images_product_id ON product_images(product_id);
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_product_images_user_id') THEN
    CREATE INDEX idx_product_images_user_id ON product_images(user_id);
  END IF;
END $$;