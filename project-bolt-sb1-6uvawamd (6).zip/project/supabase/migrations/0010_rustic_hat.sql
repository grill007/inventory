/*
  # Fix user policies and admin setup
  
  1. Changes
    - Drop and recreate policies with simplified logic
    - Create admin role and user safely
    - Fix constraint issues
*/

-- Drop existing policies
DROP POLICY IF EXISTS "user_profiles_policy" ON user_profiles;
DROP POLICY IF EXISTS "user_roles_policy" ON user_roles;

-- Simple policy for user_roles
CREATE POLICY "user_roles_select_policy"
  ON user_roles
  FOR SELECT
  TO authenticated
  USING (true);

-- Separate policies for user_profiles
CREATE POLICY "user_profiles_select_policy"
  ON user_profiles
  FOR SELECT
  TO authenticated
  USING (
    user_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM user_roles
      WHERE id = user_profiles.role_id
      AND name = 'admin'
    )
  );

CREATE POLICY "user_profiles_insert_policy"
  ON user_profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (
    auth.uid() IN (
      SELECT up.user_id
      FROM user_profiles up
      JOIN user_roles ur ON up.role_id = ur.id
      WHERE ur.name = 'admin'
    )
  );

CREATE POLICY "user_profiles_update_policy"
  ON user_profiles
  FOR UPDATE
  TO authenticated
  USING (
    auth.uid() IN (
      SELECT up.user_id
      FROM user_profiles up
      JOIN user_roles ur ON up.role_id = ur.id
      WHERE ur.name = 'admin'
    )
  );

-- Reset and create admin user safely
DO $$
DECLARE
  v_admin_role_id uuid;
  v_admin_user_id uuid;
BEGIN
  -- Ensure admin role exists
  DELETE FROM user_roles WHERE name = 'admin';
  INSERT INTO user_roles (name, description)
  VALUES ('admin', '管理者')
  RETURNING id INTO v_admin_role_id;

  -- Get or create admin user safely
  SELECT id INTO v_admin_user_id
  FROM auth.users
  WHERE email = 'shiraishi@infogrip.net';

  IF v_admin_user_id IS NULL THEN
    INSERT INTO auth.users (
      email,
      encrypted_password,
      email_confirmed_at,
      raw_app_meta_data,
      raw_user_meta_data,
      created_at,
      updated_at
    )
    VALUES (
      'shiraishi@infogrip.net',
      crypt('gripgrip2', gen_salt('bf')),
      now(),
      '{"provider": "email", "providers": ["email"]}',
      '{}',
      now(),
      now()
    )
    RETURNING id INTO v_admin_user_id;
  ELSE
    UPDATE auth.users
    SET 
      encrypted_password = crypt('gripgrip2', gen_salt('bf')),
      updated_at = now()
    WHERE id = v_admin_user_id;
  END IF;

  -- Ensure admin profile exists
  DELETE FROM user_profiles WHERE user_id = v_admin_user_id;
  INSERT INTO user_profiles (user_id, role_id, display_name)
  VALUES (v_admin_user_id, v_admin_role_id, 'システム管理者');
END $$;