/*
  # Clean up and fix admin role policies

  1. Changes
    - Drop all existing policies
    - Create new simplified policies without recursion
    - Add proper indexes for performance

  2. Security
    - Maintain RLS protection
    - Ensure admin access works correctly
    - Prevent infinite recursion
*/

-- Drop all existing policies
DROP POLICY IF EXISTS "roles_read_v22" ON user_roles;
DROP POLICY IF EXISTS "profiles_read_v22" ON user_profiles;
DROP POLICY IF EXISTS "profiles_insert_v22" ON user_profiles;
DROP POLICY IF EXISTS "profiles_update_v22" ON user_profiles;
DROP POLICY IF EXISTS "profiles_delete_v22" ON user_profiles;

-- Drop existing function if exists
DROP FUNCTION IF EXISTS is_admin_v22();

-- Create new policies with direct role check
CREATE POLICY "allow_read_roles"
  ON user_roles
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "allow_read_profiles"
  ON user_profiles
  FOR SELECT
  TO authenticated
  USING (
    user_id = auth.uid() OR
    role_id IN (SELECT id FROM user_roles WHERE name = 'admin')
  );

CREATE POLICY "allow_insert_profiles"
  ON user_profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (
    role_id IN (SELECT id FROM user_roles WHERE name = 'admin')
  );

CREATE POLICY "allow_update_profiles"
  ON user_profiles
  FOR UPDATE
  TO authenticated
  USING (
    role_id IN (SELECT id FROM user_roles WHERE name = 'admin')
  );

CREATE POLICY "allow_delete_profiles"
  ON user_profiles
  FOR DELETE
  TO authenticated
  USING (
    role_id IN (SELECT id FROM user_roles WHERE name = 'admin')
  );

-- Ensure indexes exist for performance
CREATE INDEX IF NOT EXISTS idx_user_profiles_user_id ON user_profiles(user_id);
CREATE INDEX IF NOT EXISTS idx_user_profiles_role_id ON user_profiles(role_id);
CREATE INDEX IF NOT EXISTS idx_user_roles_name ON user_roles(name);
CREATE INDEX IF NOT EXISTS idx_user_profiles_user_role ON user_profiles(user_id, role_id);