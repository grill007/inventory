/*
  # Fix admin login credentials

  1. Changes
    - Reset admin user password
    - Ensure admin role and profile exist
*/

DO $$
DECLARE
  v_admin_role_id uuid;
  v_admin_user_id uuid;
BEGIN
  -- Get admin role ID
  SELECT id INTO v_admin_role_id
  FROM user_roles
  WHERE name = 'admin';

  -- Get admin user ID
  SELECT id INTO v_admin_user_id
  FROM auth.users
  WHERE email = 'shiraishi@infogrip.net';

  -- Update admin user password
  UPDATE auth.users
  SET 
    encrypted_password = crypt('icecream11', gen_salt('bf')),
    email_confirmed_at = now(),
    updated_at = now()
  WHERE id = v_admin_user_id;

  -- Ensure admin profile exists
  INSERT INTO user_profiles (user_id, role_id, display_name)
  VALUES (v_admin_user_id, v_admin_role_id, 'システム管理者')
  ON CONFLICT (user_id) DO UPDATE
  SET role_id = v_admin_role_id;
END $$;