/*
  # Update Superadmin User

  1. Changes
    - Update superadmin email address
    - Ensure proper authentication setup
*/

-- Update superadmin user
UPDATE auth.users
SET 
  email = 'shiraishi@infogrip.net',
  email_confirmed_at = now()
WHERE email = 'superadmin';