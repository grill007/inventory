/*
  # Fix user roles policy recursion

  1. Changes
    - Drop existing policies on user_roles table
    - Create new non-recursive policies for user_roles
    - Add basic policies for viewing roles
*/

-- Drop existing policies on user_roles
DROP POLICY IF EXISTS "Admins can do everything with user_roles" ON user_roles;

-- Create new policies for user_roles
CREATE POLICY "Anyone can view roles"
  ON user_roles
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Only superadmin can modify roles"
  ON user_roles
  USING (
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE user_profiles.user_id = auth.uid()
      AND user_profiles.role_id = (
        SELECT id FROM user_roles WHERE name = 'admin' LIMIT 1
      )
    )
  );