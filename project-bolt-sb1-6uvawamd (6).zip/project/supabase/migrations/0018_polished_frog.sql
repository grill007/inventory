/*
  # Fix RLS policies with unique names
  
  1. Changes
    - Drop existing policies with unique suffixes
    - Create new policies with unique names
    - Add performance optimizations
  
  2. Benefits
    - Prevents policy name conflicts
    - Maintains security rules
    - Improves query performance
*/

-- Drop existing policies with unique suffixes
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "roles_read_policy_v30" ON user_roles;
  DROP POLICY IF EXISTS "profiles_read_policy_v30" ON user_profiles;
  DROP POLICY IF EXISTS "profiles_insert_policy_v30" ON user_profiles;
  DROP POLICY IF EXISTS "profiles_update_policy_v30" ON user_profiles;
  DROP POLICY IF EXISTS "profiles_delete_policy_v30" ON user_profiles;
  DROP POLICY IF EXISTS "roles_read" ON user_roles;
  DROP POLICY IF EXISTS "profiles_read" ON user_profiles;
  DROP POLICY IF EXISTS "profiles_insert" ON user_profiles;
  DROP POLICY IF EXISTS "profiles_update" ON user_profiles;
  DROP POLICY IF EXISTS "profiles_delete" ON user_profiles;
END $$;

-- Create admin check function with unique name
CREATE OR REPLACE FUNCTION is_admin_v4()
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 
    FROM user_profiles up
    JOIN user_roles ur ON up.role_id = ur.id
    WHERE up.user_id = auth.uid()
    AND ur.name = 'admin'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create policies with unique names
CREATE POLICY "roles_read_policy_v40"
  ON user_roles
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "profiles_read_policy_v40"
  ON user_profiles
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid() OR is_admin_v4());

CREATE POLICY "profiles_insert_policy_v40"
  ON user_profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (is_admin_v4());

CREATE POLICY "profiles_update_policy_v40"
  ON user_profiles
  FOR UPDATE
  TO authenticated
  USING (is_admin_v4());

CREATE POLICY "profiles_delete_policy_v40"
  ON user_profiles
  FOR DELETE
  TO authenticated
  USING (is_admin_v4());

-- Ensure indexes exist for performance
DO $$ 
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_user_profiles_user_id') THEN
    CREATE INDEX idx_user_profiles_user_id ON user_profiles(user_id);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_user_profiles_role_id') THEN
    CREATE INDEX idx_user_profiles_role_id ON user_profiles(role_id);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_user_roles_name') THEN
    CREATE INDEX idx_user_roles_name ON user_roles(name);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_user_profiles_user_role') THEN
    CREATE INDEX idx_user_profiles_user_role ON user_profiles(user_id, role_id);
  END IF;
END $$;