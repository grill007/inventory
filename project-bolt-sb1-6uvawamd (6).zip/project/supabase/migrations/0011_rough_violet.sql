/*
  # Enable passwordless authentication
  
  1. Changes
    - Remove password requirement
    - Update admin user for passwordless auth
*/

-- Update admin user to use passwordless auth
UPDATE auth.users
SET encrypted_password = NULL
WHERE email = 'shiraishi@infogrip.net';