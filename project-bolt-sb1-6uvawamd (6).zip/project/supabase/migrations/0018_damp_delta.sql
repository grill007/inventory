/*
  # Fix user management policies and optimize performance

  1. Changes
    - Drop existing problematic policies
    - Create new optimized admin check function
    - Create new simplified policies
    - Add missing indexes

  2. Security
    - Maintain proper access control
    - Prevent infinite recursion
    - Ensure data isolation
*/

-- Drop existing policies
DROP POLICY IF EXISTS "roles_read_policy_v40" ON user_roles;
DROP POLICY IF EXISTS "profiles_read_policy_v40" ON user_profiles;
DROP POLICY IF EXISTS "profiles_insert_policy_v40" ON user_profiles;
DROP POLICY IF EXISTS "profiles_update_policy_v40" ON user_profiles;
DROP POLICY IF EXISTS "profiles_delete_policy_v40" ON user_profiles;

-- Create optimized admin check function
CREATE OR REPLACE FUNCTION is_admin(user_id uuid)
RETURNS boolean AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 
    FROM user_profiles up
    JOIN user_roles ur ON up.role_id = ur.id
    WHERE up.user_id = user_id
    AND ur.name = 'admin'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create new simplified policies
CREATE POLICY "roles_read_policy"
  ON user_roles
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "profiles_read_policy"
  ON user_profiles
  FOR SELECT
  TO authenticated
  USING (
    user_id = auth.uid() OR
    is_admin(auth.uid())
  );

CREATE POLICY "profiles_insert_policy"
  ON user_profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (is_admin(auth.uid()));

CREATE POLICY "profiles_update_policy"
  ON user_profiles
  FOR UPDATE
  TO authenticated
  USING (is_admin(auth.uid()));

CREATE POLICY "profiles_delete_policy"
  ON user_profiles
  FOR DELETE
  TO authenticated
  USING (is_admin(auth.uid()));

-- Optimize indexes
DO $$ 
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_user_profiles_user_id') THEN
    CREATE INDEX idx_user_profiles_user_id ON user_profiles(user_id);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_user_profiles_role_id') THEN
    CREATE INDEX idx_user_profiles_role_id ON user_profiles(role_id);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_user_roles_name') THEN
    CREATE INDEX idx_user_roles_name ON user_roles(name);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_user_profiles_user_role') THEN
    CREATE INDEX idx_user_profiles_user_role ON user_profiles(user_id, role_id);
  END IF;
END $$;