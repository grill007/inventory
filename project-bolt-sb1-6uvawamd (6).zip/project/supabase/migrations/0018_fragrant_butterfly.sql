/*
  # Fix RLS policies and admin check
  
  1. Changes
    - Remove existing policies
    - Create materialized view for admin users
    - Add simplified policies without recursion
    - Optimize performance with indexes
*/

-- Drop existing policies
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "roles_read" ON user_roles;
  DROP POLICY IF EXISTS "profiles_read" ON user_profiles;
  DROP POLICY IF EXISTS "profiles_insert" ON user_profiles;
  DROP POLICY IF EXISTS "profiles_update" ON user_profiles;
  DROP POLICY IF EXISTS "profiles_delete" ON user_profiles;
END $$;

-- Create materialized view for admin users
CREATE MATERIALIZED VIEW IF NOT EXISTS admin_cache AS
SELECT DISTINCT up.user_id
FROM user_profiles up
JOIN user_roles ur ON up.role_id = ur.id
WHERE ur.name = 'admin';

-- Create index on materialized view
CREATE UNIQUE INDEX IF NOT EXISTS admin_cache_user_id_idx ON admin_cache(user_id);

-- Create function to refresh admin cache
CREATE OR REPLACE FUNCTION refresh_admin_cache()
RETURNS TRIGGER AS $$
BEGIN
  REFRESH MATERIALIZED VIEW CONCURRENTLY admin_cache;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to refresh cache
DROP TRIGGER IF EXISTS refresh_admin_cache_trigger ON user_profiles;
CREATE TRIGGER refresh_admin_cache_trigger
  AFTER INSERT OR UPDATE OR DELETE ON user_profiles
  FOR EACH STATEMENT
  EXECUTE FUNCTION refresh_admin_cache();

-- Create simplified policies
CREATE POLICY "allow_read_roles"
  ON user_roles
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "allow_read_profiles"
  ON user_profiles
  FOR SELECT
  TO authenticated
  USING (
    user_id = auth.uid() OR 
    EXISTS (SELECT 1 FROM admin_cache WHERE user_id = auth.uid())
  );

CREATE POLICY "allow_insert_profiles"
  ON user_profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (SELECT 1 FROM admin_cache WHERE user_id = auth.uid())
  );

CREATE POLICY "allow_update_profiles"
  ON user_profiles
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (SELECT 1 FROM admin_cache WHERE user_id = auth.uid())
  );

CREATE POLICY "allow_delete_profiles"
  ON user_profiles
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (SELECT 1 FROM admin_cache WHERE user_id = auth.uid())
  );

-- Refresh admin cache
REFRESH MATERIALIZED VIEW admin_cache;