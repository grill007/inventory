/*
  # Fix policy recursion and naming conflicts

  1. Changes
    - Drop existing policies
    - Create new simplified policies with unique names
    - Add performance indexes
*/

-- Drop existing policies
DROP POLICY IF EXISTS "roles_read_v28" ON user_roles;
DROP POLICY IF EXISTS "profiles_read_v28" ON user_profiles;
DROP POLICY IF EXISTS "profiles_insert_v28" ON user_profiles;
DROP POLICY IF EXISTS "profiles_update_v28" ON user_profiles;
DROP POLICY IF EXISTS "profiles_delete_v28" ON user_profiles;

-- Create simple read-only policy for user_roles
CREATE POLICY "roles_read_v29"
  ON user_roles
  FOR SELECT
  TO authenticated
  USING (true);

-- Create direct policies for user_profiles
CREATE POLICY "profiles_read_v29"
  ON user_profiles
  FOR SELECT
  TO authenticated
  USING (
    user_id = auth.uid() OR
    role_id IN (
      SELECT id FROM user_roles WHERE name = 'admin'
    )
  );

CREATE POLICY "profiles_insert_v29"
  ON user_profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM user_profiles up
      WHERE up.user_id = auth.uid()
      AND up.role_id IN (
        SELECT id FROM user_roles WHERE name = 'admin'
      )
    )
  );

CREATE POLICY "profiles_update_v29"
  ON user_profiles
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_profiles up
      WHERE up.user_id = auth.uid()
      AND up.role_id IN (
        SELECT id FROM user_roles WHERE name = 'admin'
      )
    )
  );

CREATE POLICY "profiles_delete_v29"
  ON user_profiles
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_profiles up
      WHERE up.user_id = auth.uid()
      AND up.role_id IN (
        SELECT id FROM user_roles WHERE name = 'admin'
      )
    )
  );

-- Ensure indexes exist for performance
DO $$ 
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_user_profiles_user_id') THEN
    CREATE INDEX idx_user_profiles_user_id ON user_profiles(user_id);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_user_profiles_role_id') THEN
    CREATE INDEX idx_user_profiles_role_id ON user_profiles(role_id);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_user_roles_name') THEN
    CREATE INDEX idx_user_roles_name ON user_roles(name);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_user_profiles_user_role') THEN
    CREATE INDEX idx_user_profiles_user_role ON user_profiles(user_id, role_id);
  END IF;
END $$;